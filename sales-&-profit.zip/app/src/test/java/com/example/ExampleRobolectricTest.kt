package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.db.AppDatabase
import com.example.data.model.Product
import com.example.data.model.Sale
import com.example.data.repository.SalesRepository
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase
    private lateinit var repository: SalesRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = SalesRepository(
            productDao = db.productDao(),
            saleDao = db.saleDao(),
            expenseDao = db.expenseDao(),
            appSettingsDao = db.appSettingsDao()
        )
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Sales & Profit", appName)
    }

    @Test
    fun `test sale inventory deduction and profit calculation`() = runBlocking {
        // 1. Add product with 10 items in stock
        val product = Product(
            name = "Premium Cotton Shirt",
            category = "Shirts",
            buyingPrice = 500.0,
            sellingPrice = 900.0,
            currentStock = 10,
            minStockAlert = 3
        )
        val prodId = repository.insertProduct(product)

        // 2. Record sale of 3 pieces
        val sale = Sale(
            productId = prodId,
            productName = "Premium Cotton Shirt",
            quantity = 3,
            buyingPricePerPiece = 500.0,
            sellingPricePerPiece = 900.0,
            totalRevenue = 2700.0,
            totalCost = 1500.0,
            grossProfit = 1200.0,
            amountPaid = 2000.0,
            remainingDue = 700.0,
            paymentStatus = "Partial"
        )
        val result = repository.recordSale(sale, allowNegativeStock = false)
        assertTrue(result.isSuccess)

        // 3. Verify stock decreased to 7 (10 - 3)
        val updatedProduct = db.productDao().getProductById(prodId)
        assertEquals(7, updatedProduct?.currentStock)

        // 4. Verify calculations
        assertEquals(2700.0, sale.totalRevenue, 0.01)
        assertEquals(1500.0, sale.totalCost, 0.01)
        assertEquals(1200.0, sale.grossProfit, 0.01)
        assertEquals(700.0, sale.remainingDue, 0.01)

        // 5. Test deleting sale restores stock
        val insertedSale = db.saleDao().getSaleById(result.getOrThrow())!!
        val deleteResult = repository.deleteSale(insertedSale)
        assertTrue(deleteResult.isSuccess)

        val restoredProduct = db.productDao().getProductById(prodId)
        assertEquals(10, restoredProduct?.currentStock)
    }
}
