package com.example.util

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object Formatters {
    // Bangladesh Standard Time (UTC+6)
    val bdTimeZone: TimeZone = TimeZone.getTimeZone("Asia/Dhaka")

    fun formatTaka(amount: Double, symbol: String = "৳"): String {
        val formatter = NumberFormat.getNumberInstance(Locale.US).apply {
            maximumFractionDigits = if (amount % 1.0 == 0.0) 0 else 2
            minimumFractionDigits = 0
        }
        return "$symbol${formatter.format(amount)}"
    }

    fun formatDate(millis: Long): String {
        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale.US)
        sdf.timeZone = bdTimeZone
        return sdf.format(Date(millis))
    }

    fun formatShortDate(millis: Long): String {
        val sdf = SimpleDateFormat("dd MMM", Locale.US)
        sdf.timeZone = bdTimeZone
        return sdf.format(Date(millis))
    }

    fun formatDateTime(millis: Long): String {
        val sdf = SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.US)
        sdf.timeZone = bdTimeZone
        return sdf.format(Date(millis))
    }

    fun getStartOfDay(timeMillis: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance(bdTimeZone)
        cal.timeInMillis = timeMillis
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun getEndOfDay(timeMillis: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance(bdTimeZone)
        cal.timeInMillis = timeMillis
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        return cal.timeInMillis
    }

    fun getStartOfMonth(timeMillis: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance(bdTimeZone)
        cal.timeInMillis = timeMillis
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun getStartOfWeek(timeMillis: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance(bdTimeZone)
        cal.timeInMillis = timeMillis
        cal.firstDayOfWeek = Calendar.SATURDAY // Bangladesh week starts Saturday or Sunday
        cal.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun isToday(millis: Long): Boolean {
        val start = getStartOfDay()
        val end = getEndOfDay()
        return millis in start..end
    }

    fun isThisMonth(millis: Long): Boolean {
        val start = getStartOfMonth()
        val cal = Calendar.getInstance(bdTimeZone)
        val end = cal.timeInMillis
        return millis >= start && millis <= end
    }

    fun isThisWeek(millis: Long): Boolean {
        val start = getStartOfWeek()
        val cal = Calendar.getInstance(bdTimeZone)
        val end = cal.timeInMillis
        return millis >= start && millis <= end
    }
}
