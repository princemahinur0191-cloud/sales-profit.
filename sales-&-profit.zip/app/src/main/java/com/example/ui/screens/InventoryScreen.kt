package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.ui.InventoryItem
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatCard
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkError
import com.example.ui.theme.DarkOnPrimary
import com.example.ui.theme.DarkPrimary
import com.example.ui.theme.DarkSuccess
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHigh
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.util.Formatters

@Composable
fun InventoryScreen(
    inventoryItems: List<InventoryItem>,
    currencySymbol: String = "৳",
    onRestockClick: (Product) -> Unit,
    onAddProductClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val totalStockValue = inventoryItems.sumOf { it.stockValue }
    val totalPotentialRevenue = inventoryItems.sumOf { it.potentialRevenue }
    val totalPotentialProfit = inventoryItems.sumOf { it.potentialProfit }
    val totalPiecesInStock = inventoryItems.sumOf { it.product.currentStock }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("inventory_screen")
    ) {
        // Summary Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard(
                title = "Total Stock Value",
                value = Formatters.formatTaka(totalStockValue, currencySymbol),
                subtitle = "$totalPiecesInStock total pieces",
                accentColor = DarkPrimary,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Potential Revenue",
                value = Formatters.formatTaka(totalPotentialRevenue, currencySymbol),
                accentColor = Color(0xFF38BDF8),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, DarkBorder),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceHigh)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Potential Gross Profit",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = DarkTextMuted
                    )
                    Text(
                        text = Formatters.formatTaka(totalPotentialProfit, currencySymbol),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = DarkSuccess
                    )
                }
                val profitMargin = if (totalPotentialRevenue > 0) (totalPotentialProfit / totalPotentialRevenue) * 100 else 0.0
                Box(
                    modifier = Modifier
                        .background(DarkSuccess.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Margin: ${String.format("%.1f", profitMargin)}%",
                        fontWeight = FontWeight.ExtraBold,
                        color = DarkSuccess,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Product Stock & Potential Valuation",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = DarkTextPrimary
        )

        Spacer(modifier = Modifier.height(10.dp))

        if (inventoryItems.isEmpty()) {
            EmptyStateView(
                title = "No inventory items yet.",
                message = "Add products to calculate stock values and potential profits.",
                actionButtonText = "+ Add First Product",
                onActionClick = onAddProductClick
            )
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(inventoryItems, key = { it.product.id }) { item ->
                    val prod = item.product
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("inventory_card_${prod.id}"),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, DarkBorder),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            // Header
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = prod.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = DarkTextPrimary
                                    )
                                    Text(
                                        text = prod.category,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = DarkPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                if (item.isLowStock) {
                                    Box(
                                        modifier = Modifier
                                            .background(DarkError.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                Icons.Default.Warning,
                                                contentDescription = null,
                                                tint = DarkError,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "LOW STOCK: ${prod.currentStock} left",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = DarkError
                                            )
                                        }
                                    }
                                } else {
                                    Text(
                                        text = "${prod.currentStock} pieces",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = DarkPrimary
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Grid of valuations
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Stock Value", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted)
                                    Text(
                                        Formatters.formatTaka(item.stockValue, currencySymbol),
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = DarkTextPrimary
                                    )
                                    Text("Cost: ${Formatters.formatTaka(prod.buyingPrice, currencySymbol)}/pc", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Potential Rev", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted)
                                    Text(
                                        Formatters.formatTaka(item.potentialRevenue, currencySymbol),
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = DarkTextPrimary
                                    )
                                    Text("Sell: ${Formatters.formatTaka(prod.sellingPrice, currencySymbol)}/pc", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Potential Profit", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted)
                                    Text(
                                        Formatters.formatTaka(item.potentialProfit, currencySymbol),
                                        fontWeight = FontWeight.Bold,
                                        color = DarkSuccess,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    val margin = if (item.potentialRevenue > 0) (item.potentialProfit / item.potentialRevenue) * 100 else 0.0
                                    Text("${String.format("%.1f", margin)}% margin", style = MaterialTheme.typography.labelSmall, color = DarkSuccess)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Quick Restock Button
                            Button(
                                onClick = { onRestockClick(prod) },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DarkPrimary, contentColor = DarkOnPrimary),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Update Stock", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
