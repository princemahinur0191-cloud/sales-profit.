package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Sale
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.EmptyStateView
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkError
import com.example.ui.theme.DarkPrimary
import com.example.ui.theme.DarkSuccess
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHigh
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.util.Formatters

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SalesScreen(
    sales: List<Sale>,
    currencySymbol: String = "৳",
    onAddSaleClick: () -> Unit,
    onEditSaleClick: (Sale) -> Unit,
    onDeleteSaleClick: (Sale) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedDateFilter by remember { mutableStateOf("All") }
    var selectedStatusFilter by remember { mutableStateOf("All") }
    var selectedMethodFilter by remember { mutableStateOf("All") }
    var saleToDelete by remember { mutableStateOf<Sale?>(null) }
    var showFilterBar by remember { mutableStateOf(false) }

    val filteredSales = sales.filter { sale ->
        val matchesSearch = searchQuery.isBlank() ||
                sale.productName.contains(searchQuery, ignoreCase = true) ||
                sale.customerName.contains(searchQuery, ignoreCase = true) ||
                sale.customerPhone.contains(searchQuery) ||
                sale.notes.contains(searchQuery, ignoreCase = true)

        val matchesDate = when (selectedDateFilter) {
            "Today" -> Formatters.isToday(sale.date)
            "This Week" -> Formatters.isThisWeek(sale.date)
            "This Month" -> Formatters.isThisMonth(sale.date)
            else -> true
        }

        val matchesStatus = selectedStatusFilter == "All" || sale.paymentStatus.equals(selectedStatusFilter, ignoreCase = true)
        val matchesMethod = selectedMethodFilter == "All" || sale.paymentMethod.equals(selectedMethodFilter, ignoreCase = true)

        matchesSearch && matchesDate && matchesStatus && matchesMethod
    }

    val totalFilteredRevenue = filteredSales.sumOf { it.totalRevenue }
    val totalFilteredProfit = filteredSales.sumOf { it.grossProfit }
    val totalFilteredPieces = filteredSales.sumOf { it.quantity }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("sales_screen")
    ) {
        // Search & Filter Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search sales, products, customers...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("sales_search_input")
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = { showFilterBar = !showFilterBar },
                modifier = Modifier
                    .background(
                        if (showFilterBar) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                        else MaterialTheme.colorScheme.surfaceVariant,
                        CircleShape
                    )
            ) {
                Icon(
                    Icons.Default.FilterList,
                    contentDescription = "Filters",
                    tint = if (showFilterBar) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Filter chips bar
        if (showFilterBar) {
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, DarkBorder),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Date Range:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = DarkTextMuted)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("All", "Today", "This Week", "This Month").forEach { d ->
                            FilterChip(
                                selected = selectedDateFilter == d,
                                onClick = { selectedDateFilter = d },
                                label = { Text(d) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Payment Status:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = DarkTextMuted)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("All", "Paid", "Partial", "Due").forEach { s ->
                            FilterChip(
                                selected = selectedStatusFilter == s,
                                onClick = { selectedStatusFilter = s },
                                label = { Text(s) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Payment Method:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = DarkTextMuted)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("All", "Cash", "bKash", "Nagad", "Bank", "Other").forEach { m ->
                            FilterChip(
                                selected = selectedMethodFilter == m,
                                onClick = { selectedMethodFilter = m },
                                label = { Text(m) }
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Summary bar for current list
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, DarkBorder),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceHigh)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Total Sales (${filteredSales.size})", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted)
                    Text(
                        Formatters.formatTaka(totalFilteredRevenue, currencySymbol),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = DarkTextPrimary
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Pieces", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted)
                    Text(
                        "$totalFilteredPieces pcs",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = DarkPrimary
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Gross Profit", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted)
                    Text(
                        Formatters.formatTaka(totalFilteredProfit, currencySymbol),
                        fontWeight = FontWeight.Bold,
                        color = DarkSuccess,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (filteredSales.isEmpty()) {
            EmptyStateView(
                title = if (sales.isEmpty()) "No sales recorded yet." else "No sales match your filters.",
                message = if (sales.isEmpty()) "Tap below to record your first clothing sale" else "Try clearing your search query or changing filters",
                actionButtonText = if (sales.isEmpty()) "Add Your First Sale" else "Clear Filters",
                onActionClick = {
                    if (sales.isEmpty()) onAddSaleClick()
                    else {
                        searchQuery = ""
                        selectedDateFilter = "All"
                        selectedStatusFilter = "All"
                        selectedMethodFilter = "All"
                    }
                }
            )
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredSales, key = { it.id }) { sale ->
                    SaleItemCard(
                        sale = sale,
                        currencySymbol = currencySymbol,
                        onEdit = { onEditSaleClick(sale) },
                        onDelete = { saleToDelete = sale }
                    )
                }
            }
        }
    }

    // Confirmation Dialog before deleting a sale (Requirement 5)
    saleToDelete?.let { sale ->
        ConfirmationDialog(
            title = "Delete Sale?",
            message = "Are you sure you want to delete this sale of ${sale.quantity} pcs of ${sale.productName}? This will return ${sale.quantity} pieces back to inventory.",
            confirmButtonText = "Delete & Restore Stock",
            isDestructive = true,
            onConfirm = {
                onDeleteSaleClick(sale)
                saleToDelete = null
            },
            onDismiss = { saleToDelete = null }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SaleItemCard(
    sale: Sale,
    currencySymbol: String,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("sale_card_${sale.id}"),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, DarkBorder),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Row: Date and Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = Formatters.formatDate(sale.date),
                    style = MaterialTheme.typography.labelMedium,
                    color = DarkTextMuted
                )
                val (statusBg, statusFg) = when (sale.paymentStatus) {
                    "Paid" -> Pair(DarkSuccess.copy(alpha = 0.15f), DarkSuccess)
                    "Partial" -> Pair(Color(0xFFD97706).copy(alpha = 0.15f), Color(0xFFFBBF24))
                    else -> Pair(DarkError.copy(alpha = 0.15f), DarkError)
                }
                Box(
                    modifier = Modifier
                        .background(statusBg, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "${sale.paymentStatus} • ${sale.paymentMethod}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = statusFg
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Product & Quantity
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = sale.productName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = DarkTextPrimary
                )
                Text(
                    text = "${sale.quantity} pcs",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = DarkPrimary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Financial breakdown
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Revenue: ${Formatters.formatTaka(sale.totalRevenue, currencySymbol)}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = DarkTextPrimary
                    )
                    Text(
                        text = "Cost: ${Formatters.formatTaka(sale.totalCost, currencySymbol)} (৳${sale.buyingPricePerPiece}/pc)",
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkTextMuted
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Profit: ${Formatters.formatTaka(sale.grossProfit, currencySymbol)}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (sale.grossProfit >= 0) DarkSuccess else DarkError
                    )
                    if (sale.remainingDue > 0) {
                        Text(
                            text = "Due: ${Formatters.formatTaka(sale.remainingDue, currencySymbol)}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = DarkError
                        )
                    }
                }
            }

            // Customer and Notes if present
            if (sale.customerName.isNotEmpty() || sale.customerPhone.isNotEmpty() || sale.notes.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurfaceHigh, RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    if (sale.customerName.isNotEmpty() || sale.customerPhone.isNotEmpty()) {
                        Text(
                            text = "Customer: ${sale.customerName} ${if (sale.customerPhone.isNotEmpty()) "(${sale.customerPhone})" else ""}".trim(),
                            style = MaterialTheme.typography.bodySmall,
                            color = DarkTextPrimary
                        )
                    }
                    if (sale.notes.isNotEmpty()) {
                        Text(
                            text = "Note: ${sale.notes}",
                            style = MaterialTheme.typography.bodySmall,
                            color = DarkTextMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Actions: Edit and Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                    Icon(
                        Icons.Default.Edit,
                        contentDescription = "Edit Sale",
                        tint = DarkPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete Sale",
                        tint = DarkError,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
