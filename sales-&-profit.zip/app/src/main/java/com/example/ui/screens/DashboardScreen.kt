package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Sale
import com.example.ui.AppDestination
import com.example.ui.DashboardData
import com.example.ui.SummaryMetrics
import com.example.ui.components.BarChartItem
import com.example.ui.components.SimpleBarChart
import com.example.ui.components.StatCard
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkBorderSubtle
import com.example.ui.theme.DarkError
import com.example.ui.theme.DarkPrimary
import com.example.ui.theme.DarkSuccess
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHigh
import com.example.ui.theme.DarkSurfaceSubtle
import com.example.ui.theme.DarkSurfaceVariant
import com.example.util.Formatters

@Composable
fun DashboardScreen(
    dashboardData: DashboardData,
    recentSales: List<Sale>,
    lowStockCount: Int,
    currencySymbol: String = "৳",
    onNavigate: (AppDestination) -> Unit,
    onAddSaleClick: () -> Unit,
    onAddExpenseClick: () -> Unit,
    onAddProductClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("dashboard_screen")
    ) {
        // Elegant Dark Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SALES MANAGER",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 2.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Financial Overview",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(DarkSurfaceSubtle, CircleShape)
                    .border(1.dp, DarkBorderSubtle, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = currencySymbol,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = DarkPrimary
                )
            }
        }

        // Quick Actions Section (Requirement 28)
        Text(
            text = "QUICK ACTIONS",
            style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onAddSaleClick,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = DarkPrimary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("quick_add_sale_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Sale", fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = onAddExpenseClick,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = DarkSurfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ),
                border = BorderStroke(1.dp, DarkBorder),
                modifier = Modifier
                    .weight(1f)
                    .testTag("quick_add_expense_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Expense", fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = onAddProductClick,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = DarkSurfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ),
                border = BorderStroke(1.dp, DarkBorder),
                modifier = Modifier
                    .weight(1f)
                    .testTag("quick_add_product_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Product", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedButton(
            onClick = { onNavigate(AppDestination.REPORTS) },
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, DarkBorder),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = MaterialTheme.colorScheme.onSurface
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("view_reports_button")
        ) {
            Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(18.dp), tint = DarkPrimary)
            Spacer(modifier = Modifier.width(8.dp))
            Text("View Comprehensive Reports & Trends")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Total Due Money Card (Requirement 12)
        if (dashboardData.totalDueMoney > 0) {
            Card(
                onClick = { onNavigate(AppDestination.DUE_PAYMENTS) },
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, DarkBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_due_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(DarkError.copy(alpha = 0.12f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Receipt,
                                contentDescription = null,
                                tint = DarkError
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "CURRENT DUE MONEY",
                                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = Formatters.formatTaka(dashboardData.totalDueMoney, currencySymbol),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = DarkError
                            )
                        }
                    }
                    Icon(
                        Icons.Default.ArrowForward,
                        contentDescription = "View Due Payments",
                        tint = DarkError
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Low Stock Warning Banner (Elegant Dark alert style)
        if (lowStockCount > 0) {
            Card(
                onClick = { onNavigate(AppDestination.INVENTORY) },
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                border = BorderStroke(1.dp, DarkBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(DarkError.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = null,
                                tint = DarkError
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "LOW STOCK ALERTS",
                                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
                                fontWeight = FontWeight.Bold,
                                color = DarkPrimary
                            )
                            Text(
                                text = "$lowStockCount products running low on stock",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Text(
                        text = "Restock →",
                        fontWeight = FontWeight.Bold,
                        color = DarkPrimary,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // 1. TODAY METRICS (Requirement 3 - Spotlight Presentation)
        MetricsSection(
            sectionTitle = "TODAY",
            metrics = dashboardData.today,
            currencySymbol = currencySymbol,
            accentColor = DarkPrimary
        )

        Spacer(modifier = Modifier.height(20.dp))

        // 2. THIS MONTH METRICS (Requirement 3)
        MetricsSection(
            sectionTitle = "THIS MONTH",
            metrics = dashboardData.thisMonth,
            currencySymbol = currencySymbol,
            accentColor = MaterialTheme.colorScheme.secondary
        )

        Spacer(modifier = Modifier.height(20.dp))

        // 3. ALL TIME METRICS (Requirement 3)
        MetricsSection(
            sectionTitle = "ALL TIME",
            metrics = dashboardData.allTime,
            currencySymbol = currencySymbol,
            accentColor = DarkPrimary
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Sales & Profit Comparison Chart
        val chartItems = listOf(
            BarChartItem("Today", dashboardData.today.sales, dashboardData.today.netProfit),
            BarChartItem("Month", dashboardData.thisMonth.sales, dashboardData.thisMonth.netProfit),
            BarChartItem("All Time", dashboardData.allTime.sales, dashboardData.allTime.netProfit)
        )
        SimpleBarChart(
            title = "Sales & Net Profit",
            items = chartItems,
            showSecondaryLegend = true,
            primaryLegendText = "Sales",
            secondaryLegendText = "Net Profit",
            primaryColor = DarkPrimary,
            secondaryColor = DarkSuccess
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Recent Sales List Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "RECENT SALES",
                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (recentSales.isNotEmpty()) {
                Text(
                    text = "View All →",
                    style = MaterialTheme.typography.labelMedium,
                    color = DarkPrimary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (recentSales.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, DarkBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "No sales recorded yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onAddSaleClick,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DarkPrimary, contentColor = MaterialTheme.colorScheme.onPrimary)
                    ) {
                        Text("+ Record First Sale", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            recentSales.take(5).forEach { sale ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = BorderStroke(1.dp, DarkBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = sale.productName,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${sale.quantity} pcs • ${Formatters.formatShortDate(sale.date)} • ${sale.paymentMethod}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = Formatters.formatTaka(sale.totalRevenue, currencySymbol),
                                fontWeight = FontWeight.Bold,
                                color = DarkPrimary
                            )
                            Text(
                                text = "Profit: ${Formatters.formatTaka(sale.grossProfit, currencySymbol)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = DarkSuccess,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
fun MetricsSection(
    sectionTitle: String,
    metrics: SummaryMetrics,
    currencySymbol: String,
    accentColor: Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceHigh),
        border = BorderStroke(1.dp, DarkBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header with pill badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .background(accentColor.copy(alpha = 0.12f), RoundedCornerShape(50))
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "$sectionTitle'S NET PROFIT",
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
                        fontWeight = FontWeight.Bold,
                        color = accentColor
                    )
                }

                Text(
                    text = "${metrics.piecesSold} pcs sold",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Spotlight Net Profit Amount Display
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = Formatters.formatTaka(metrics.netProfit, currencySymbol),
                    style = MaterialTheme.typography.headlineLarge.copy(fontSize = 32.sp),
                    fontWeight = FontWeight.Bold,
                    color = if (metrics.netProfit >= 0) MaterialTheme.colorScheme.onSurface else DarkError
                )

                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(
                            (if (metrics.netProfit >= 0) DarkSuccess else DarkError).copy(alpha = 0.15f),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.MonetizationOn,
                        contentDescription = null,
                        tint = if (metrics.netProfit >= 0) DarkSuccess else DarkError,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = DarkBorder, thickness = 1.dp)
            Spacer(modifier = Modifier.height(14.dp))

            // Sub-grid: Sales & Cost
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Sales",
                    value = Formatters.formatTaka(metrics.sales, currencySymbol),
                    icon = Icons.Default.ShoppingBag,
                    accentColor = DarkPrimary,
                    containerColor = DarkSurface,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Cost",
                    value = Formatters.formatTaka(metrics.cost, currencySymbol),
                    icon = Icons.Default.Inventory2,
                    accentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    containerColor = DarkSurface,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sub-grid: Gross Profit & Expenses
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Gross Profit",
                    value = Formatters.formatTaka(metrics.grossProfit, currencySymbol),
                    subtitle = "Margin: ${String.format("%.1f", metrics.profitMargin)}%",
                    icon = Icons.Default.TrendingUp,
                    accentColor = DarkSuccess,
                    containerColor = DarkSurface,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Expenses",
                    value = Formatters.formatTaka(metrics.expenses, currencySymbol),
                    icon = Icons.Default.Receipt,
                    accentColor = DarkError,
                    containerColor = DarkSurface,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
