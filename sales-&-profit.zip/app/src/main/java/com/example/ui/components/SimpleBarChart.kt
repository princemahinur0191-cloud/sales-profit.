package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkPrimary
import com.example.ui.theme.DarkSuccess
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary

data class BarChartItem(
    val label: String,
    val value: Double,
    val secondaryValue: Double = 0.0,
    val displayValue: String = ""
)

@Composable
fun SimpleBarChart(
    title: String,
    items: List<BarChartItem>,
    modifier: Modifier = Modifier,
    primaryColor: Color = DarkPrimary,
    secondaryColor: Color = DarkSuccess,
    showSecondaryLegend: Boolean = false,
    primaryLegendText: String = "Sales",
    secondaryLegendText: String = "Profit"
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, DarkBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = DarkTextPrimary
                )
                if (showSecondaryLegend) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .width(10.dp)
                                .height(10.dp)
                                .background(primaryColor, RoundedCornerShape(3.dp))
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = primaryLegendText,
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextMuted
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Box(
                            modifier = Modifier
                                .width(10.dp)
                                .height(10.dp)
                                .background(secondaryColor, RoundedCornerShape(3.dp))
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = secondaryLegendText,
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (items.isEmpty() || items.all { it.value == 0.0 && it.secondaryValue == 0.0 }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No chart data recorded yet",
                        style = MaterialTheme.typography.bodyMedium,
                        color = DarkTextMuted
                    )
                }
            } else {
                val maxValue = maxOf(1.0, items.maxOf { maxOf(it.value, it.secondaryValue) })
                val baselineColor = DarkBorder

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                ) {
                    val count = items.size
                    val availableWidth = size.width
                    val availableHeight = size.height - 20f
                    val slotWidth = availableWidth / count
                    val barWidth = if (showSecondaryLegend) (slotWidth * 0.32f) else (slotWidth * 0.5f)
                    val cornerRadius = CornerRadius(8f, 8f)

                    // Draw baseline
                    drawLine(
                        color = baselineColor,
                        start = Offset(0f, availableHeight),
                        end = Offset(availableWidth, availableHeight),
                        strokeWidth = 1.5f
                    )

                    items.forEachIndexed { index, item ->
                        val slotCenter = index * slotWidth + (slotWidth / 2f)

                        if (showSecondaryLegend) {
                            // Primary bar
                            val pHeight = ((item.value / maxValue) * availableHeight).toFloat().coerceIn(4f, availableHeight)
                            val pLeft = slotCenter - barWidth - 3f
                            val pTop = availableHeight - pHeight
                            drawRoundRect(
                                color = primaryColor,
                                topLeft = Offset(pLeft, pTop),
                                size = Size(barWidth, pHeight),
                                cornerRadius = cornerRadius
                            )

                            // Secondary bar
                            val sHeight = ((item.secondaryValue / maxValue) * availableHeight).toFloat().coerceIn(4f, availableHeight)
                            val sLeft = slotCenter + 3f
                            val sTop = availableHeight - sHeight
                            drawRoundRect(
                                color = secondaryColor,
                                topLeft = Offset(sLeft, sTop),
                                size = Size(barWidth, sHeight),
                                cornerRadius = cornerRadius
                            )
                        } else {
                            // Single bar
                            val barHeight = ((item.value / maxValue) * availableHeight).toFloat().coerceIn(4f, availableHeight)
                            val left = slotCenter - (barWidth / 2f)
                            val top = availableHeight - barHeight

                            drawRoundRect(
                                color = primaryColor,
                                topLeft = Offset(left, top),
                                size = Size(barWidth, barHeight),
                                cornerRadius = cornerRadius
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    items.forEach { item ->
                        Text(
                            text = item.label,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                            color = DarkTextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}
