package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ==========================================
// Elegant Dark Design Theme Palette
// ==========================================

// Base Canvas & Surfaces
val DarkBackground = Color(0xFF111318)       // Deep Obsidian / Charcoal Canvas
val DarkSurface = Color(0xFF1C1E23)          // Primary Card / Navigation Surface
val DarkSurfaceHigh = Color(0xFF212329)      // Elevated Spotlight Container (32dp card)
val DarkSurfaceVariant = Color(0xFF2D2F36)   // Secondary Accent Container / Alert Card
val DarkSurfaceSubtle = Color(0xFF2E3036)    // Pill / Icon Badge Container

// Borders & Dividers
val DarkBorder = Color(0xFF33353B)           // Primary Element Stroke
val DarkBorderSubtle = Color(0xFF44474E)     // Elevated & Accent Stroke

// Text Colors
val DarkTextPrimary = Color(0xFFE2E2E6)      // Soft Off-White Heading & Body
val DarkTextMuted = Color(0xFFA8ADBD)        // Secondary Muted / Tracking Label
val DarkTextSecondary = Color(0xFFC4C7D0)

// Brand Accents
val DarkPrimary = Color(0xFFD0BCFF)          // Luminous Lavender Accent
val DarkOnPrimary = Color(0xFF381E72)        // Deep Royal Violet (High Contrast on Primary)
val DarkPrimaryContainer = Color(0xFF4F378B)
val DarkOnPrimaryContainer = Color(0xFFEADDFF)

val DarkSecondary = Color(0xFFCCC2DC)
val DarkOnSecondary = Color(0xFF332D41)
val DarkSecondaryContainer = Color(0xFF4A4458)
val DarkOnSecondaryContainer = Color(0xFFE8DEF8)

val DarkTertiary = Color(0xFFEFB8C8)
val DarkOnTertiary = Color(0xFF492532)
val DarkTertiaryContainer = Color(0xFF633B48)
val DarkOnTertiaryContainer = Color(0xFFFFD8E4)

// Semantic Accents
val DarkSuccess = Color(0xFF4CD964)          // Clean Emerald for Positive Margins / Trends
val DarkSuccessContainer = Color(0xFF17381E)
val DarkWarning = Color(0xFFFBBF24)          // Warm Amber
val DarkError = Color(0xFFFFB4AB)            // Soft Coral / Rose for Due & Stock Alerts
val DarkErrorContainer = Color(0xFF4E1616)
val DarkOnError = Color(0xFF690005)

// Complementary Light Palette (for toggle consistency)
val LightPrimary = Color(0xFF6750A4)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFEADDFF)
val LightOnPrimaryContainer = Color(0xFF21005D)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE7E0EC)
