package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.model.AppSettings
import com.example.ui.components.ConfirmationDialog
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkError
import com.example.ui.theme.DarkOnPrimary
import com.example.ui.theme.DarkPrimary
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHigh
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onSaveSettings: (AppSettings) -> Unit,
    onExportJson: suspend () -> String,
    onImportJson: (String) -> Unit,
    onExportCsv: suspend (type: String) -> String,
    onLoadSampleData: () -> Unit,
    onResetAllData: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var businessName by remember(settings.businessName) { mutableStateOf(settings.businessName) }
    var allowNegativeStock by remember(settings.allowNegativeStock) { mutableStateOf(settings.allowNegativeStock) }
    var darkMode by remember(settings.darkMode) { mutableStateOf(settings.darkMode) }

    // Dialogs state
    var showExportDialog by remember { mutableStateOf(false) }
    var exportedJsonText by remember { mutableStateOf("") }
    var showImportDialog by remember { mutableStateOf(false) }
    var importJsonInput by remember { mutableStateOf("") }
    var showImportWarningConfirm by remember { mutableStateOf(false) }

    var showResetConfirmStep1 by remember { mutableStateOf(false) }
    var showResetConfirmStep2 by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("settings_screen")
    ) {
        // Business Profile
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, DarkBorder),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Storefront, contentDescription = null, tint = DarkPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Business Information", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = DarkTextPrimary)
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = businessName,
                    onValueChange = { businessName = it },
                    label = { Text("Business / Store Name") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_business_name_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Currency: ৳ (Bangladeshi Taka - BDT)",
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkTextMuted
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        onSaveSettings(
                            settings.copy(
                                businessName = businessName.trim(),
                                allowNegativeStock = allowNegativeStock,
                                darkMode = darkMode,
                                useSystemTheme = false
                            )
                        )
                        Toast.makeText(context, "Settings saved!", Toast.LENGTH_SHORT).show()
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DarkPrimary, contentColor = DarkOnPrimary),
                    modifier = Modifier
                        .align(Alignment.End)
                        .testTag("save_settings_button")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Save Changes", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Business Preferences & Inventory Rules
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, DarkBorder),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Preferences & Inventory Rules", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = DarkTextPrimary)

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Allow Negative Stock", fontWeight = FontWeight.SemiBold, color = DarkTextPrimary)
                        Text(
                            "When disabled, sales cannot exceed the available stock quantity in inventory.",
                            style = MaterialTheme.typography.bodySmall,
                            color = DarkTextMuted
                        )
                    }
                    Switch(
                        checked = allowNegativeStock,
                        onCheckedChange = {
                            allowNegativeStock = it
                            onSaveSettings(settings.copy(allowNegativeStock = it))
                        },
                        modifier = Modifier.testTag("toggle_negative_stock")
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Dark Mode Theme", fontWeight = FontWeight.SemiBold, color = DarkTextPrimary)
                        Text(
                            "Toggle between comfortable dark and crisp light themes.",
                            style = MaterialTheme.typography.bodySmall,
                            color = DarkTextMuted
                        )
                    }
                    Switch(
                        checked = darkMode,
                        onCheckedChange = {
                            darkMode = it
                            onSaveSettings(settings.copy(darkMode = it, useSystemTheme = false))
                        },
                        modifier = Modifier.testTag("toggle_dark_mode")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Data Management (Requirement 14: Export/Import, CSV, Reset)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, DarkBorder),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Data Management & Backups", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = DarkTextPrimary)
                Text(
                    "Your records are stored securely on your local device. Back them up regularly.",
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkTextMuted
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Backup JSON
                Button(
                    onClick = {
                        scope.launch {
                            exportedJsonText = onExportJson()
                            showExportDialog = true
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DarkPrimary, contentColor = DarkOnPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("export_backup_button")
                ) {
                    Icon(Icons.Default.CloudDownload, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Backup Data (Export JSON)", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Restore JSON
                OutlinedButton(
                    onClick = { showImportDialog = true },
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, DarkBorder),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = DarkPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("restore_backup_button")
                ) {
                    Icon(Icons.Default.CloudUpload, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Restore from Backup (Import JSON)")
                }

                Spacer(modifier = Modifier.height(12.dp))

                // CSV Export Section
                Text("Export Spreadsheets (CSV):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, color = DarkTextPrimary)
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            scope.launch {
                                val csv = onExportCsv("sales")
                                copyToClipboard(context, "Sales CSV", csv)
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceHigh, contentColor = DarkTextPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Sales CSV", style = MaterialTheme.typography.labelSmall)
                    }
                    Button(
                        onClick = {
                            scope.launch {
                                val csv = onExportCsv("expenses")
                                copyToClipboard(context, "Expenses CSV", csv)
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceHigh, contentColor = DarkTextPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Expenses CSV", style = MaterialTheme.typography.labelSmall)
                    }
                    Button(
                        onClick = {
                            scope.launch {
                                val csv = onExportCsv("products")
                                copyToClipboard(context, "Products CSV", csv)
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceHigh, contentColor = DarkTextPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Products CSV", style = MaterialTheme.typography.labelSmall)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Load Sample Data (For Instant Testing)
                OutlinedButton(
                    onClick = onLoadSampleData,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, DarkBorder),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = DarkPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("load_sample_data_button")
                ) {
                    Icon(Icons.Default.RestartAlt, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Load Sample Boutique Data")
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Reset All Data (Double Confirmation - Requirement 14)
                Button(
                    onClick = { showResetConfirmStep1 = true },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DarkError, contentColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reset_all_data_button")
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Reset All Business Data", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
    }

    // Export Dialog
    if (showExportDialog) {
        Dialog(onDismissRequest = { showExportDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, DarkBorder),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceHigh)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Backup Export Ready", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = DarkTextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("You can copy this JSON string and save it to your notes or send it as a backup file.", style = MaterialTheme.typography.bodySmall, color = DarkTextMuted)
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = exportedJsonText,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Button(
                            onClick = {
                                copyToClipboard(context, "Sales Backup JSON", exportedJsonText)
                                showExportDialog = false
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DarkPrimary, contentColor = DarkOnPrimary)
                        ) {
                            Text("Copy to Clipboard")
                        }
                    }
                }
            }
        }
    }

    // Import Dialog
    if (showImportDialog) {
        Dialog(onDismissRequest = { showImportDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, DarkBorder),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceHigh)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Restore from JSON Backup", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = DarkTextPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Paste your exported JSON backup data here:", style = MaterialTheme.typography.bodySmall, color = DarkTextMuted)
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = importJsonInput,
                        onValueChange = { importJsonInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        label = { Text("Paste JSON here") }
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        OutlinedButton(onClick = { showImportDialog = false }, border = BorderStroke(1.dp, DarkBorder)) {
                            Text("Cancel", color = DarkTextMuted)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (importJsonInput.isNotBlank()) {
                                    showImportDialog = false
                                    showImportWarningConfirm = true
                                }
                            },
                            enabled = importJsonInput.isNotBlank(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DarkPrimary, contentColor = DarkOnPrimary)
                        ) {
                            Text("Continue")
                        }
                    }
                }
            }
        }
    }

    // Strong confirmation before replacing existing data (Requirement 14)
    if (showImportWarningConfirm) {
        ConfirmationDialog(
            title = "Replace Current Data?",
            message = "This will replace your current sales, inventory, and expense data with the backup file. Are you sure you want to continue?",
            confirmButtonText = "Yes, Replace Data",
            isDestructive = true,
            onConfirm = {
                onImportJson(importJsonInput)
                showImportWarningConfirm = false
                importJsonInput = ""
            },
            onDismiss = { showImportWarningConfirm = false }
        )
    }

    // Double Confirmation for Reset Data (Requirement 14)
    if (showResetConfirmStep1) {
        ConfirmationDialog(
            title = "Warning: Reset All Business Data?",
            message = "This will erase ALL sales, expenses, and inventory records. This action cannot be undone. Are you sure?",
            confirmButtonText = "Proceed to Final Check",
            isDestructive = true,
            onConfirm = {
                showResetConfirmStep1 = false
                showResetConfirmStep2 = true
            },
            onDismiss = { showResetConfirmStep1 = false }
        )
    }

    if (showResetConfirmStep2) {
        ConfirmationDialog(
            title = "Final Confirmation Required",
            message = "Please confirm a second time: Do you definitely want to wipe the entire database clean and start over?",
            confirmButtonText = "I Understand, Wipe Everything",
            isDestructive = true,
            onConfirm = {
                onResetAllData()
                showResetConfirmStep2 = false
            },
            onDismiss = { showResetConfirmStep2 = false }
        )
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(label, text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "$label copied to clipboard!", Toast.LENGTH_SHORT).show()
}
