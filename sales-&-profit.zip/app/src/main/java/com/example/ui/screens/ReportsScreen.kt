package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Expense
import com.example.data.model.Sale
import com.example.ui.PerformanceSortOption
import com.example.ui.ProductPerformanceItem
import com.example.ui.ReportPeriod
import com.example.ui.SummaryMetrics
import com.example.ui.components.BarChartItem
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SimpleBarChart
import com.example.ui.components.StatCard
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkError
import com.example.ui.theme.DarkPrimary
import com.example.ui.theme.DarkSuccess
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHigh
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.util.Formatters

@Composable
fun ReportsScreen(
    sales: List<Sale>,
    expenses: List<Expense>,
    currencySymbol: String = "৳",
    onComputeReport: (ReportPeriod) -> SummaryMetrics,
    onComputePerformance: (PerformanceSortOption) -> List<ProductPerformanceItem>,
    modifier: Modifier = Modifier
) {
    var selectedPeriod by remember { mutableStateOf(ReportPeriod.MONTHLY) }
    var selectedSortOption by remember { mutableStateOf(PerformanceSortOption.MOST_PIECES) }

    val reportMetrics = onComputeReport(selectedPeriod)
    val performanceItems = onComputePerformance(selectedSortOption)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("reports_screen")
    ) {
        // Period Tabs
        val periods = listOf(
            ReportPeriod.DAILY to "Daily",
            ReportPeriod.WEEKLY to "Weekly",
            ReportPeriod.MONTHLY to "Monthly",
            ReportPeriod.ALL_TIME to "All Time"
        )
        TabRow(
            selectedTabIndex = periods.indexOfFirst { it.first == selectedPeriod }
        ) {
            periods.forEach { (p, label) ->
                Tab(
                    selected = selectedPeriod == p,
                    onClick = { selectedPeriod = p },
                    text = { Text(label, fontWeight = FontWeight.SemiBold) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Net Profit Highlight Banner
        val isNetPositive = reportMetrics.netProfit >= 0
        val netColor = if (isNetPositive) DarkSuccess else DarkError
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, DarkBorder),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceHigh)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "${selectedPeriod.name.replace("_", " ")} NET PROFIT",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = DarkTextMuted
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = Formatters.formatTaka(reportMetrics.netProfit, currencySymbol),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = netColor
                    )
                    Box(
                        modifier = Modifier
                            .background(
                                netColor.copy(alpha = 0.15f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Margin: ${String.format("%.1f", reportMetrics.profitMargin)}%",
                            fontWeight = FontWeight.Bold,
                            color = netColor
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Breakdown Cards Grid
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(
                title = "Revenue",
                value = Formatters.formatTaka(reportMetrics.sales, currencySymbol),
                subtitle = "${reportMetrics.piecesSold} pcs sold",
                icon = Icons.Default.ShoppingBag,
                accentColor = DarkPrimary,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Cost of Goods",
                value = Formatters.formatTaka(reportMetrics.cost, currencySymbol),
                icon = Icons.Default.Inventory2,
                accentColor = DarkTextMuted,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(
                title = "Gross Profit",
                value = Formatters.formatTaka(reportMetrics.grossProfit, currencySymbol),
                icon = Icons.Default.TrendingUp,
                accentColor = DarkSuccess,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Operating Expenses",
                value = Formatters.formatTaka(reportMetrics.expenses, currencySymbol),
                icon = Icons.Default.Receipt,
                accentColor = DarkError,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Top 5 Products Bar Chart
        val topChartItems = performanceItems.take(5).map { item ->
            BarChartItem(
                label = item.productName.take(8),
                value = item.revenue,
                secondaryValue = item.grossProfit
            )
        }
        SimpleBarChart(
            title = "Top Products Revenue vs Gross Profit",
            items = topChartItems,
            showSecondaryLegend = true,
            primaryLegendText = "Revenue",
            secondaryLegendText = "Gross Profit"
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Product Performance Section (Requirement 11)
        Text(
            text = "Product Performance Analytics",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = DarkTextPrimary
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Sort Options (Requirement 11: 1. Most pieces sold, 2. Highest revenue, 3. Highest profit)
        Text("Sort Products By:", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted)
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedSortOption == PerformanceSortOption.MOST_PIECES,
                onClick = { selectedSortOption = PerformanceSortOption.MOST_PIECES },
                label = { Text("1. Most Pieces Sold") }
            )
            FilterChip(
                selected = selectedSortOption == PerformanceSortOption.HIGHEST_REVENUE,
                onClick = { selectedSortOption = PerformanceSortOption.HIGHEST_REVENUE },
                label = { Text("2. Highest Revenue") }
            )
            FilterChip(
                selected = selectedSortOption == PerformanceSortOption.HIGHEST_PROFIT,
                onClick = { selectedSortOption = PerformanceSortOption.HIGHEST_PROFIT },
                label = { Text("3. Highest Profit") }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (performanceItems.isEmpty()) {
            EmptyStateView(
                title = "No sales data for performance analytics.",
                message = "Record sales to see itemized breakdowns.",
                icon = Icons.Default.BarChart
            )
        } else {
            performanceItems.forEachIndexed { index, item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, DarkBorder),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "#${index + 1} ${item.productName}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = DarkTextPrimary
                            )
                            Text(
                                text = "${item.piecesSold} pcs",
                                fontWeight = FontWeight.ExtraBold,
                                color = DarkPrimary,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Revenue: ${Formatters.formatTaka(item.revenue, currencySymbol)}", style = MaterialTheme.typography.bodySmall, color = DarkTextMuted)
                                Text("Cost: ${Formatters.formatTaka(item.cost, currencySymbol)}", style = MaterialTheme.typography.bodySmall, color = DarkTextMuted)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    "Gross Profit: ${Formatters.formatTaka(item.grossProfit, currencySymbol)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = DarkSuccess
                                )
                                Text(
                                    "Avg Sell: ${Formatters.formatTaka(item.avgSellingPrice, currencySymbol)}/pc",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = DarkTextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
