package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Sale
import com.example.ui.components.EmptyStateView
import com.example.ui.dialogs.PayDueDialog
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkError
import com.example.ui.theme.DarkOnPrimary
import com.example.ui.theme.DarkPrimary
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHigh
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.util.Formatters

@Composable
fun DuePaymentsScreen(
    salesWithDue: List<Sale>,
    currencySymbol: String = "৳",
    onRecordPayment: (saleId: Long, amount: Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSaleForPayment by remember { mutableStateOf<Sale?>(null) }
    val totalDue = salesWithDue.sumOf { it.remainingDue }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("due_payments_screen")
    ) {
        // Header Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, DarkBorder),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceHigh)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Total Due Money to Collect",
                        style = MaterialTheme.typography.labelMedium,
                        color = DarkTextMuted
                    )
                    Text(
                        text = Formatters.formatTaka(totalDue, currencySymbol),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = DarkError
                    )
                }
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(DarkError.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Receipt,
                        contentDescription = null,
                        tint = DarkError,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Pending Customer Balances (${salesWithDue.size})",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = DarkTextPrimary
        )

        Spacer(modifier = Modifier.height(10.dp))

        if (salesWithDue.isEmpty()) {
            EmptyStateView(
                title = "All Payments Clear!",
                message = "You have no outstanding customer dues. Great job!",
                icon = Icons.Default.CheckCircle
            )
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(salesWithDue, key = { it.id }) { sale ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("due_card_${sale.id}"),
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, DarkBorder),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = sale.customerName.ifEmpty { "Customer (Walk-in)" },
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = DarkTextPrimary
                                    )
                                    if (sale.customerPhone.isNotEmpty()) {
                                        Text(
                                            text = "Phone: ${sale.customerPhone}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = DarkPrimary,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                                Text(
                                    text = Formatters.formatDate(sale.date),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = DarkTextMuted
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "Item: ${sale.productName} • ${sale.quantity} pcs",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = DarkTextPrimary
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Total: ${Formatters.formatTaka(sale.totalRevenue, currencySymbol)}", color = DarkTextMuted, style = MaterialTheme.typography.bodyMedium)
                                Text("Paid: ${Formatters.formatTaka(sale.amountPaid, currencySymbol)}", color = DarkTextMuted, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    "Due: ${Formatters.formatTaka(sale.remainingDue, currencySymbol)}",
                                    fontWeight = FontWeight.Bold,
                                    color = DarkError,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = { selectedSaleForPayment = sale },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DarkPrimary, contentColor = DarkOnPrimary),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("collect_payment_button_${sale.id}")
                            ) {
                                Text("Record Due Payment", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    selectedSaleForPayment?.let { sale ->
        PayDueDialog(
            sale = sale,
            onDismiss = { selectedSaleForPayment = null },
            onConfirmPayment = { amount ->
                onRecordPayment(sale.id, amount)
                selectedSaleForPayment = null
            }
        )
    }
}
