package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.AppSettings
import com.example.data.model.Expense
import com.example.data.model.Product
import com.example.data.model.Sale
import com.example.data.repository.SalesRepository
import com.example.util.Formatters
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SummaryMetrics(
    val sales: Double = 0.0,
    val cost: Double = 0.0,
    val grossProfit: Double = 0.0,
    val expenses: Double = 0.0,
    val netProfit: Double = 0.0,
    val piecesSold: Int = 0,
    val profitMargin: Double = 0.0
)

data class DashboardData(
    val today: SummaryMetrics = SummaryMetrics(),
    val thisMonth: SummaryMetrics = SummaryMetrics(),
    val allTime: SummaryMetrics = SummaryMetrics(),
    val totalDueMoney: Double = 0.0
)

data class InventoryItem(
    val product: Product,
    val stockValue: Double,
    val potentialRevenue: Double,
    val potentialProfit: Double,
    val isLowStock: Boolean
)

data class ProductPerformanceItem(
    val productName: String,
    val piecesSold: Int,
    val revenue: Double,
    val cost: Double,
    val grossProfit: Double,
    val avgSellingPrice: Double,
    val profitMargin: Double
)

enum class AppDestination(val title: String) {
    DASHBOARD("Dashboard"),
    SALES("Sales History"),
    PRODUCTS("Products"),
    INVENTORY("Inventory"),
    EXPENSES("Expenses"),
    DUE_PAYMENTS("Due Payments"),
    REPORTS("Reports"),
    SETTINGS("Settings")
}

enum class PerformanceSortOption {
    MOST_PIECES,
    HIGHEST_REVENUE,
    HIGHEST_PROFIT
}

enum class ReportPeriod {
    DAILY,
    WEEKLY,
    MONTHLY,
    ALL_TIME
}

class SalesViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getInstance(application)
    private val repository = SalesRepository(
        productDao = database.productDao(),
        saleDao = database.saleDao(),
        expenseDao = database.expenseDao(),
        appSettingsDao = database.appSettingsDao()
    )

    val products: StateFlow<List<Product>> = repository.allProducts.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val sales: StateFlow<List<Sale>> = repository.allSales.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val expenses: StateFlow<List<Expense>> = repository.allExpenses.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val settings: StateFlow<AppSettings> = repository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AppSettings()
    )

    val currentDestination = MutableStateFlow(AppDestination.DASHBOARD)
    val searchQuery = MutableStateFlow("")

    private val _messageFlow = MutableSharedFlow<String>()
    val messageFlow: SharedFlow<String> = _messageFlow

    val dashboardData: StateFlow<DashboardData> = combine(sales, expenses) { salesList, expensesList ->
        computeDashboardData(salesList, expensesList)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardData()
    )

    val inventoryItems: StateFlow<List<InventoryItem>> = products.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    ).let { flow ->
        flow.combine(flow) { prods, _ ->
            prods.map { p ->
                val stockValue = p.currentStock * p.buyingPrice
                val potentialRev = p.currentStock * p.sellingPrice
                val potentialProfit = potentialRev - stockValue
                val isLow = p.currentStock <= p.minStockAlert
                InventoryItem(
                    product = p,
                    stockValue = stockValue,
                    potentialRevenue = potentialRev,
                    potentialProfit = potentialProfit,
                    isLowStock = isLow
                )
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    private fun computeDashboardData(salesList: List<Sale>, expensesList: List<Expense>): DashboardData {
        val startOfToday = Formatters.getStartOfDay()
        val endOfToday = Formatters.getEndOfDay()
        val startOfMonth = Formatters.getStartOfMonth()

        // Today metrics
        val todaySales = salesList.filter { it.date in startOfToday..endOfToday }
        val todayExpenses = expensesList.filter { it.date in startOfToday..endOfToday }
        val todayRevenue = todaySales.sumOf { it.totalRevenue }
        val todayCost = todaySales.sumOf { it.totalCost }
        val todayGross = todayRevenue - todayCost
        val todayExpTotal = todayExpenses.sumOf { it.amount }
        val todayNet = todayGross - todayExpTotal
        val todayPieces = todaySales.sumOf { it.quantity }
        val todayMargin = if (todayRevenue > 0) (todayGross / todayRevenue) * 100 else 0.0

        // This Month metrics
        val monthSales = salesList.filter { it.date >= startOfMonth }
        val monthExpenses = expensesList.filter { it.date >= startOfMonth }
        val monthRevenue = monthSales.sumOf { it.totalRevenue }
        val monthCost = monthSales.sumOf { it.totalCost }
        val monthGross = monthRevenue - monthCost
        val monthExpTotal = monthExpenses.sumOf { it.amount }
        val monthNet = monthGross - monthExpTotal
        val monthPieces = monthSales.sumOf { it.quantity }
        val monthMargin = if (monthRevenue > 0) (monthGross / monthRevenue) * 100 else 0.0

        // All Time metrics
        val allRevenue = salesList.sumOf { it.totalRevenue }
        val allCost = salesList.sumOf { it.totalCost }
        val allGross = allRevenue - allCost
        val allExpTotal = expensesList.sumOf { it.amount }
        val allNet = allGross - allExpTotal
        val allPieces = salesList.sumOf { it.quantity }
        val allMargin = if (allRevenue > 0) (allGross / allRevenue) * 100 else 0.0

        // Total Due Money
        val totalDue = salesList.sumOf { it.remainingDue }

        return DashboardData(
            today = SummaryMetrics(
                sales = todayRevenue,
                cost = todayCost,
                grossProfit = todayGross,
                expenses = todayExpTotal,
                netProfit = todayNet,
                piecesSold = todayPieces,
                profitMargin = todayMargin
            ),
            thisMonth = SummaryMetrics(
                sales = monthRevenue,
                cost = monthCost,
                grossProfit = monthGross,
                expenses = monthExpTotal,
                netProfit = monthNet,
                piecesSold = monthPieces,
                profitMargin = monthMargin
            ),
            allTime = SummaryMetrics(
                sales = allRevenue,
                cost = allCost,
                grossProfit = allGross,
                expenses = allExpTotal,
                netProfit = allNet,
                piecesSold = allPieces,
                profitMargin = allMargin
            ),
            totalDueMoney = totalDue
        )
    }

    fun computePerformance(
        salesList: List<Sale>,
        sortOption: PerformanceSortOption
    ): List<ProductPerformanceItem> {
        val grouped = salesList.groupBy { it.productName }
        val list = grouped.map { (prodName, list) ->
            val pieces = list.sumOf { it.quantity }
            val rev = list.sumOf { it.totalRevenue }
            val cost = list.sumOf { it.totalCost }
            val gross = rev - cost
            val avgSelling = if (pieces > 0) rev / pieces else 0.0
            val margin = if (rev > 0) (gross / rev) * 100 else 0.0
            ProductPerformanceItem(
                productName = prodName,
                piecesSold = pieces,
                revenue = rev,
                cost = cost,
                grossProfit = gross,
                avgSellingPrice = avgSelling,
                profitMargin = margin
            )
        }

        return when (sortOption) {
            PerformanceSortOption.MOST_PIECES -> list.sortedByDescending { it.piecesSold }
            PerformanceSortOption.HIGHEST_REVENUE -> list.sortedByDescending { it.revenue }
            PerformanceSortOption.HIGHEST_PROFIT -> list.sortedByDescending { it.grossProfit }
        }
    }

    fun computeReport(period: ReportPeriod, salesList: List<Sale>, expensesList: List<Expense>): SummaryMetrics {
        val now = System.currentTimeMillis()
        val filteredSales = when (period) {
            ReportPeriod.DAILY -> {
                val start = Formatters.getStartOfDay(now)
                val end = Formatters.getEndOfDay(now)
                salesList.filter { it.date in start..end }
            }
            ReportPeriod.WEEKLY -> {
                val start = Formatters.getStartOfWeek(now)
                salesList.filter { it.date >= start }
            }
            ReportPeriod.MONTHLY -> {
                val start = Formatters.getStartOfMonth(now)
                salesList.filter { it.date >= start }
            }
            ReportPeriod.ALL_TIME -> salesList
        }

        val filteredExpenses = when (period) {
            ReportPeriod.DAILY -> {
                val start = Formatters.getStartOfDay(now)
                val end = Formatters.getEndOfDay(now)
                expensesList.filter { it.date in start..end }
            }
            ReportPeriod.WEEKLY -> {
                val start = Formatters.getStartOfWeek(now)
                expensesList.filter { it.date >= start }
            }
            ReportPeriod.MONTHLY -> {
                val start = Formatters.getStartOfMonth(now)
                expensesList.filter { it.date >= start }
            }
            ReportPeriod.ALL_TIME -> expensesList
        }

        val rev = filteredSales.sumOf { it.totalRevenue }
        val cost = filteredSales.sumOf { it.totalCost }
        val gross = rev - cost
        val exp = filteredExpenses.sumOf { it.amount }
        val net = gross - exp
        val pieces = filteredSales.sumOf { it.quantity }
        val margin = if (rev > 0) (gross / rev) * 100 else 0.0

        return SummaryMetrics(
            sales = rev,
            cost = cost,
            grossProfit = gross,
            expenses = exp,
            netProfit = net,
            piecesSold = pieces,
            profitMargin = margin
        )
    }

    // Actions
    fun recordSale(
        sale: Sale,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val currentSettings = settings.value
            val result = repository.recordSale(sale, currentSettings.allowNegativeStock)
            if (result.isSuccess) {
                _messageFlow.emit("Sale recorded successfully! Stock updated.")
                onSuccess()
            } else {
                val msg = result.exceptionOrNull()?.message ?: "Failed to record sale"
                onError(msg)
            }
        }
    }

    fun updateSale(
        oldSale: Sale,
        newSale: Sale,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val currentSettings = settings.value
            val result = repository.updateSale(oldSale, newSale, currentSettings.allowNegativeStock)
            if (result.isSuccess) {
                _messageFlow.emit("Sale updated and inventory corrected.")
                onSuccess()
            } else {
                val msg = result.exceptionOrNull()?.message ?: "Failed to update sale"
                onError(msg)
            }
        }
    }

    fun deleteSale(sale: Sale, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val result = repository.deleteSale(sale)
            if (result.isSuccess) {
                _messageFlow.emit("Sale deleted. ${sale.quantity} pieces returned to stock.")
                onSuccess()
            } else {
                _messageFlow.emit(result.exceptionOrNull()?.message ?: "Failed to delete sale")
            }
        }
    }

    fun addDuePayment(saleId: Long, amount: Double, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            val result = repository.updateDuePayment(saleId, amount)
            if (result.isSuccess) {
                _messageFlow.emit("Payment recorded successfully!")
                onSuccess()
            } else {
                _messageFlow.emit(result.exceptionOrNull()?.message ?: "Error recording payment")
            }
        }
    }

    fun saveProduct(product: Product, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            if (product.id == 0L) {
                repository.insertProduct(product)
                _messageFlow.emit("Product added successfully!")
            } else {
                repository.updateProduct(product)
                _messageFlow.emit("Product updated successfully!")
            }
            onSuccess()
        }
    }

    fun deleteProduct(product: Product, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteProduct(product)
            _messageFlow.emit("Product removed.")
            onSuccess()
        }
    }

    fun quickRestock(productId: Long, newStock: Int, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateProductStock(productId, newStock)
            _messageFlow.emit("Stock adjusted to $newStock pieces.")
            onSuccess()
        }
    }

    fun saveExpense(expense: Expense, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            if (expense.id == 0L) {
                repository.insertExpense(expense)
                _messageFlow.emit("Expense recorded.")
            } else {
                repository.updateExpense(expense)
                _messageFlow.emit("Expense updated.")
            }
            onSuccess()
        }
    }

    fun deleteExpense(expense: Expense, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteExpense(expense)
            _messageFlow.emit("Expense deleted.")
            onSuccess()
        }
    }

    fun saveSettings(newSettings: AppSettings) {
        viewModelScope.launch {
            repository.saveSettings(newSettings)
            _messageFlow.emit("Settings saved.")
        }
    }

    fun loadSampleData(onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.loadSampleData()
            _messageFlow.emit("Sample clothing boutique data loaded!")
            onSuccess()
        }
    }

    fun resetAllData(onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.resetAllData()
            _messageFlow.emit("All business data reset.")
            onSuccess()
        }
    }

    suspend fun exportJson(): String {
        return repository.exportAllDataAsJson(
            products = products.value,
            sales = sales.value,
            expenses = expenses.value,
            settings = settings.value
        )
    }

    fun importJson(json: String, onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) {
        viewModelScope.launch {
            val result = repository.importDataFromJson(json)
            if (result.isSuccess) {
                _messageFlow.emit("Backup restored successfully!")
                onSuccess()
            } else {
                val err = result.exceptionOrNull()?.message ?: "Invalid JSON backup file"
                onError(err)
            }
        }
    }

    suspend fun exportCsv(type: String): String {
        return repository.generateCsv(type, products.value, sales.value, expenses.value)
    }
}
