package com.example.ui.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Product
import com.example.data.model.Sale
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkError
import com.example.ui.theme.DarkOnPrimary
import com.example.ui.theme.DarkPrimary
import com.example.ui.theme.DarkSuccess
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHigh
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.util.Formatters

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditSaleDialog(
    existingSale: Sale? = null,
    products: List<Product>,
    allowNegativeStock: Boolean = false,
    onDismiss: () -> Unit,
    onSave: (Sale) -> Unit
) {
    var selectedProduct by remember {
        mutableStateOf(
            if (existingSale != null) {
                products.find { it.id == existingSale.productId }
            } else {
                products.firstOrNull()
            }
        )
    }

    var quantityStr by remember { mutableStateOf((existingSale?.quantity ?: 1).toString()) }
    var buyingPriceStr by remember {
        mutableStateOf(
            (existingSale?.buyingPricePerPiece ?: selectedProduct?.buyingPrice ?: 0.0).toString()
        )
    }
    var sellingPriceStr by remember {
        mutableStateOf(
            (existingSale?.sellingPricePerPiece ?: selectedProduct?.sellingPrice ?: 0.0).toString()
        )
    }
    var customerName by remember { mutableStateOf(existingSale?.customerName ?: "") }
    var customerPhone by remember { mutableStateOf(existingSale?.customerPhone ?: "") }
    var paymentStatus by remember { mutableStateOf(existingSale?.paymentStatus ?: "Paid") }
    var paymentMethod by remember { mutableStateOf(existingSale?.paymentMethod ?: "Cash") }
    var amountPaidStr by remember {
        mutableStateOf(
            if (existingSale != null) existingSale.amountPaid.toString() else ""
        )
    }
    var notes by remember { mutableStateOf(existingSale?.notes ?: "") }
    var productDropdownExpanded by remember { mutableStateOf(false) }

    val quantity = quantityStr.toIntOrNull() ?: 0
    val buyingPrice = buyingPriceStr.toDoubleOrNull() ?: 0.0
    val sellingPrice = sellingPriceStr.toDoubleOrNull() ?: 0.0

    val totalRevenue by remember(quantity, sellingPrice) {
        derivedStateOf { quantity * sellingPrice }
    }
    val totalCost by remember(quantity, buyingPrice) {
        derivedStateOf { quantity * buyingPrice }
    }
    val grossProfit by remember(totalRevenue, totalCost) {
        derivedStateOf { totalRevenue - totalCost }
    }

    val amountPaid by remember(paymentStatus, amountPaidStr, totalRevenue) {
        derivedStateOf {
            when (paymentStatus) {
                "Paid" -> totalRevenue
                "Due" -> 0.0
                else -> (amountPaidStr.toDoubleOrNull() ?: 0.0).coerceIn(0.0, totalRevenue)
            }
        }
    }

    val remainingDue by remember(totalRevenue, amountPaid) {
        derivedStateOf { (totalRevenue - amountPaid).coerceAtLeast(0.0) }
    }

    // Inventory check
    val availableStock = remember(selectedProduct, existingSale) {
        val baseStock = selectedProduct?.currentStock ?: 0
        if (existingSale != null && existingSale.productId == selectedProduct?.id) {
            baseStock + existingSale.quantity
        } else {
            baseStock
        }
    }

    val isStockInsufficient = !allowNegativeStock && quantity > availableStock
    val isFormValid = selectedProduct != null && quantity > 0 && sellingPrice >= 0 && buyingPrice >= 0 && !isStockInsufficient

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 16.dp)
                .testTag("add_sale_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = DarkSurface,
            border = BorderStroke(1.dp, DarkBorder),
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (existingSale != null) "Edit Sale" else "+ Add New Sale",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = DarkTextPrimary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = DarkTextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Product Selection
                Text(
                    text = "Select Product *",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = DarkTextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Box(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkSurfaceHigh, RoundedCornerShape(12.dp))
                            .border(
                                width = 1.dp,
                                color = DarkBorder,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { productDropdownExpanded = true }
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = selectedProduct?.let { "${it.name} (Stock: ${it.currentStock})" }
                                    ?: "Select a product",
                                style = MaterialTheme.typography.bodyLarge,
                                color = if (selectedProduct != null) DarkTextPrimary
                                else DarkTextMuted
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = DarkTextMuted)
                        }
                    }

                    DropdownMenu(
                        expanded = productDropdownExpanded,
                        onDismissRequest = { productDropdownExpanded = false }
                    ) {
                        products.forEach { prod ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = prod.name,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Text(
                                            text = "Stock: ${prod.currentStock} pcs | Buying: ৳${prod.buyingPrice} | Selling: ৳${prod.sellingPrice}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = DarkTextMuted
                                        )
                                    }
                                },
                                onClick = {
                                    selectedProduct = prod
                                    buyingPriceStr = prod.buyingPrice.toString()
                                    sellingPriceStr = prod.sellingPrice.toString()
                                    productDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                if (selectedProduct == null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Please select a product first or add one in Products section",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Quantity & Stock Check
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = quantityStr,
                        onValueChange = { quantityStr = it },
                        label = { Text("Quantity (pcs) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("sale_quantity_input"),
                        isError = quantity <= 0 || isStockInsufficient
                    )

                    OutlinedTextField(
                        value = sellingPriceStr,
                        onValueChange = { sellingPriceStr = it },
                        label = { Text("Selling Price / pc (৳) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1.3f)
                            .testTag("sale_selling_price_input")
                    )
                }

                if (isStockInsufficient) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Exceeds available stock ($availableStock pcs remaining). Allow negative stock in Settings to bypass.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Buying Price (Editable to lock historical cost)
                OutlinedTextField(
                    value = buyingPriceStr,
                    onValueChange = { buyingPriceStr = it },
                    label = { Text("Buying Cost / pc (৳) (Historical)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sale_buying_price_input"),
                    supportingText = {
                        Text("Locked for this sale. Changes to product price later won't affect this.")
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // AUTOMATIC LIVE CALCULATION CARD (Requirement 4)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, DarkBorder),
                    colors = CardDefaults.cardColors(
                        containerColor = DarkSurfaceHigh
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Automatic Calculations",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = DarkPrimary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Total Revenue ($sellingPrice × $quantity):", color = DarkTextMuted)
                            Text(
                                text = Formatters.formatTaka(totalRevenue),
                                fontWeight = FontWeight.Bold,
                                color = DarkTextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Total Cost ($buyingPrice × $quantity):", color = DarkTextMuted)
                            Text(
                                text = Formatters.formatTaka(totalCost),
                                fontWeight = FontWeight.Bold,
                                color = DarkTextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Gross Profit (Revenue − Cost):",
                                fontWeight = FontWeight.SemiBold,
                                color = DarkTextPrimary
                            )
                            Text(
                                text = Formatters.formatTaka(grossProfit),
                                fontWeight = FontWeight.ExtraBold,
                                color = if (grossProfit >= 0) DarkSuccess else DarkError
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Payment Status
                Text(
                    text = "Payment Status",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = DarkTextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Paid", "Partial", "Due").forEach { status ->
                        FilterChip(
                            selected = paymentStatus == status,
                            onClick = { paymentStatus = status },
                            label = { Text(status) },
                            modifier = Modifier.testTag("payment_status_$status")
                        )
                    }
                }

                if (paymentStatus == "Partial") {
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = amountPaidStr,
                        onValueChange = { amountPaidStr = it },
                        label = { Text("Amount Paid (৳) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth(),
                        supportingText = {
                            Text("Remaining Due: ${Formatters.formatTaka(remainingDue)}", color = DarkError)
                        }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Payment Method
                Text(
                    text = "Payment Method",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = DarkTextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf("Cash", "bKash", "Nagad", "Bank", "Other").forEach { method ->
                        FilterChip(
                            selected = paymentMethod == method,
                            onClick = { paymentMethod = method },
                            label = { Text(method) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Customer Info
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("Customer Name (Optional)") },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = customerPhone,
                        onValueChange = { customerPhone = it },
                        label = { Text("Phone (Optional)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (Optional)") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, DarkBorder)
                    ) {
                        Text("Cancel", color = DarkTextMuted)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = {
                            if (isFormValid && selectedProduct != null) {
                                val saleToSave = Sale(
                                    id = existingSale?.id ?: 0L,
                                    date = existingSale?.date ?: System.currentTimeMillis(),
                                    productId = selectedProduct!!.id,
                                    productName = selectedProduct!!.name,
                                    quantity = quantity,
                                    buyingPricePerPiece = buyingPrice,
                                    sellingPricePerPiece = sellingPrice,
                                    totalRevenue = totalRevenue,
                                    totalCost = totalCost,
                                    grossProfit = grossProfit,
                                    customerName = customerName.trim(),
                                    customerPhone = customerPhone.trim(),
                                    paymentStatus = paymentStatus,
                                    paymentMethod = paymentMethod,
                                    amountPaid = amountPaid,
                                    remainingDue = remainingDue,
                                    notes = notes.trim()
                                )
                                onSave(saleToSave)
                            }
                        },
                        enabled = isFormValid,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DarkPrimary, contentColor = DarkOnPrimary),
                        modifier = Modifier.testTag("save_sale_button")
                    ) {
                        Text(if (existingSale != null) "Update Sale" else "Save Sale", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
