package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.EmptyStateView
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkError
import com.example.ui.theme.DarkOnPrimary
import com.example.ui.theme.DarkPrimary
import com.example.ui.theme.DarkSuccess
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHigh
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.util.Formatters

@Composable
fun ProductsScreen(
    products: List<Product>,
    currencySymbol: String = "৳",
    onAddProductClick: () -> Unit,
    onEditProductClick: (Product) -> Unit,
    onDeleteProductClick: (Product) -> Unit,
    onRestockClick: (Product) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var productToDelete by remember { mutableStateOf<Product?>(null) }

    val filteredProducts = products.filter { prod ->
        searchQuery.isBlank() ||
                prod.name.contains(searchQuery, ignoreCase = true) ||
                prod.category.contains(searchQuery, ignoreCase = true) ||
                prod.notes.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("products_screen")
    ) {
        // Search & Add Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search products or category...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("products_search_input")
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = onAddProductClick,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("add_product_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (filteredProducts.isEmpty()) {
            EmptyStateView(
                title = if (products.isEmpty()) "No products added yet." else "No products found.",
                message = if (products.isEmpty()) "Tap Add Product to register your clothing catalog." else "Try searching with a different keyword.",
                actionButtonText = if (products.isEmpty()) "Add Product" else "Clear Search",
                icon = Icons.Default.Inventory,
                onActionClick = {
                    if (products.isEmpty()) onAddProductClick() else searchQuery = ""
                }
            )
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredProducts, key = { it.id }) { product ->
                    ProductItemCard(
                        product = product,
                        currencySymbol = currencySymbol,
                        onEdit = { onEditProductClick(product) },
                        onDelete = { productToDelete = product },
                        onRestock = { onRestockClick(product) }
                    )
                }
            }
        }
    }

    productToDelete?.let { prod ->
        ConfirmationDialog(
            title = "Delete Product?",
            message = "Are you sure you want to delete '${prod.name}'? Existing past sales records will still preserve their historical data.",
            confirmButtonText = "Delete Product",
            isDestructive = true,
            onConfirm = {
                onDeleteProductClick(prod)
                productToDelete = null
            },
            onDismiss = { productToDelete = null }
        )
    }
}

@Composable
fun ProductItemCard(
    product: Product,
    currencySymbol: String,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onRestock: () -> Unit
) {
    val isLowStock = product.currentStock <= product.minStockAlert

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("product_card_${product.id}"),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, DarkBorder),
        colors = CardDefaults.cardColors(containerColor = DarkSurface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = product.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DarkTextPrimary
                    )
                    Text(
                        text = product.category,
                        style = MaterialTheme.typography.labelMedium,
                        color = DarkPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Stock Badge
                val stockBg = if (isLowStock) DarkError.copy(alpha = 0.15f) else DarkSuccess.copy(alpha = 0.15f)
                val stockColor = if (isLowStock) DarkError else DarkSuccess
                Box(
                    modifier = Modifier
                        .background(stockBg, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (isLowStock) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = null,
                                tint = stockColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Text(
                            text = "${product.currentStock} pcs",
                            fontWeight = FontWeight.Bold,
                            color = stockColor,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }

            if (isLowStock) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "LOW STOCK: ${product.currentStock} pieces remaining (Min: ${product.minStockAlert})",
                    style = MaterialTheme.typography.labelSmall,
                    color = DarkError,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Pricing Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Buying: ${Formatters.formatTaka(product.buyingPrice, currencySymbol)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = DarkTextMuted
                )
                Text(
                    text = "Selling: ${Formatters.formatTaka(product.sellingPrice, currencySymbol)}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = DarkTextPrimary
                )
                val marginPerPiece = product.sellingPrice - product.buyingPrice
                Text(
                    text = "Margin: ${Formatters.formatTaka(marginPerPiece, currencySymbol)}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = DarkSuccess
                )
            }

            if (product.notes.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = product.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkTextMuted
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onRestock,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DarkPrimary,
                        contentColor = DarkOnPrimary
                    )
                ) {
                    Text("+ Update Stock", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }

                Row {
                    IconButton(onClick = onEdit) {
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "Edit Product",
                            tint = DarkPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(onClick = onDelete) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Delete Product",
                            tint = DarkError,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
