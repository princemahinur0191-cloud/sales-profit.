package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkError
import com.example.ui.theme.DarkOnPrimary
import com.example.ui.theme.DarkPrimary
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.Expense
import com.example.data.model.Product
import com.example.data.model.Sale
import com.example.ui.dialogs.AddEditExpenseDialog
import com.example.ui.dialogs.AddEditProductDialog
import com.example.ui.dialogs.AddEditSaleDialog
import com.example.ui.dialogs.QuickRestockDialog
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DuePaymentsScreen
import com.example.ui.screens.ExpensesScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.ProductsScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SalesScreen
import com.example.ui.screens.SettingsScreen
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    viewModel: SalesViewModel = viewModel()
) {
    val currentDestination by viewModel.currentDestination.collectAsState()
    val products by viewModel.products.collectAsState()
    val sales by viewModel.sales.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val dashboardData by viewModel.dashboardData.collectAsState()
    val inventoryItems by viewModel.inventoryItems.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // Dialog States
    var showAddSaleDialog by remember { mutableStateOf(false) }
    var saleToEdit by remember { mutableStateOf<Sale?>(null) }

    var showAddProductDialog by remember { mutableStateOf(false) }
    var productToEdit by remember { mutableStateOf<Product?>(null) }
    var productToRestock by remember { mutableStateOf<Product?>(null) }

    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var expenseToEdit by remember { mutableStateOf<Expense?>(null) }

    var showMoreSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState()

    // Listen to ViewModel message flow
    LaunchedEffect(Unit) {
        viewModel.messageFlow.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val lowStockCount = remember(products) {
        products.count { it.currentStock <= it.minStockAlert }
    }
    val dueCount = remember(sales) {
        sales.count { it.remainingDue > 0 }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        Row(modifier = Modifier.fillMaxSize()) {
            // Navigation Rail on Tablets / Expanded Screens
            if (isWideScreen) {
                NavigationRail(
                    modifier = Modifier.fillMaxHeight(),
                    containerColor = DarkSurface,
                    header = {
                        FloatingActionButton(
                            onClick = { showAddSaleDialog = true },
                            shape = RoundedCornerShape(16.dp),
                            containerColor = DarkPrimary,
                            contentColor = DarkOnPrimary,
                            modifier = Modifier.padding(vertical = 12.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add Sale")
                        }
                    }
                ) {
                    val railColors = NavigationRailItemDefaults.colors(
                        selectedIconColor = DarkPrimary,
                        selectedTextColor = DarkPrimary,
                        indicatorColor = DarkPrimary.copy(alpha = 0.2f),
                        unselectedIconColor = DarkTextMuted,
                        unselectedTextColor = DarkTextMuted
                    )
                    NavigationRailItem(
                        selected = currentDestination == AppDestination.DASHBOARD,
                        onClick = { viewModel.currentDestination.value = AppDestination.DASHBOARD },
                        icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
                        label = { Text("Dashboard") },
                        colors = railColors
                    )
                    NavigationRailItem(
                        selected = currentDestination == AppDestination.SALES,
                        onClick = { viewModel.currentDestination.value = AppDestination.SALES },
                        icon = { Icon(Icons.Default.ShoppingCart, contentDescription = null) },
                        label = { Text("Sales") },
                        colors = railColors
                    )
                    NavigationRailItem(
                        selected = currentDestination == AppDestination.PRODUCTS,
                        onClick = { viewModel.currentDestination.value = AppDestination.PRODUCTS },
                        icon = { Icon(Icons.Default.Inventory2, contentDescription = null) },
                        label = { Text("Products") },
                        colors = railColors
                    )
                    NavigationRailItem(
                        selected = currentDestination == AppDestination.INVENTORY,
                        onClick = { viewModel.currentDestination.value = AppDestination.INVENTORY },
                        icon = {
                            if (lowStockCount > 0) {
                                BadgedBox(badge = { Badge { Text("$lowStockCount") } }) {
                                    Icon(Icons.Default.Inventory, contentDescription = null)
                                }
                            } else {
                                Icon(Icons.Default.Inventory, contentDescription = null)
                            }
                        },
                        label = { Text("Inventory") },
                        colors = railColors
                    )
                    NavigationRailItem(
                        selected = currentDestination == AppDestination.EXPENSES,
                        onClick = { viewModel.currentDestination.value = AppDestination.EXPENSES },
                        icon = { Icon(Icons.Default.Receipt, contentDescription = null) },
                        label = { Text("Expenses") },
                        colors = railColors
                    )
                    NavigationRailItem(
                        selected = currentDestination == AppDestination.DUE_PAYMENTS,
                        onClick = { viewModel.currentDestination.value = AppDestination.DUE_PAYMENTS },
                        icon = {
                            if (dueCount > 0) {
                                BadgedBox(badge = { Badge { Text("$dueCount") } }) {
                                    Icon(Icons.Default.AccountBalanceWallet, contentDescription = null)
                                }
                            } else {
                                Icon(Icons.Default.AccountBalanceWallet, contentDescription = null)
                            }
                        },
                        label = { Text("Due") },
                        colors = railColors
                    )
                    NavigationRailItem(
                        selected = currentDestination == AppDestination.REPORTS,
                        onClick = { viewModel.currentDestination.value = AppDestination.REPORTS },
                        icon = { Icon(Icons.Default.TrendingUp, contentDescription = null) },
                        label = { Text("Reports") },
                        colors = railColors
                    )
                    NavigationRailItem(
                        selected = currentDestination == AppDestination.SETTINGS,
                        onClick = { viewModel.currentDestination.value = AppDestination.SETTINGS },
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        label = { Text("Settings") },
                        colors = railColors
                    )
                }
            }

            // Main Scaffold
            Scaffold(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                containerColor = DarkBackground,
                topBar = {
                    TopAppBar(
                        title = {
                            Text(
                                text = if (currentDestination == AppDestination.DASHBOARD) settings.businessName
                                else currentDestination.title,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        },
                        actions = {
                            // Due Payments Shortcut Icon with Badge
                            IconButton(onClick = { viewModel.currentDestination.value = AppDestination.DUE_PAYMENTS }) {
                                if (dueCount > 0) {
                                    BadgedBox(badge = { Badge { Text("$dueCount") } }) {
                                        Icon(
                                            Icons.Default.AccountBalanceWallet,
                                            contentDescription = "Due Payments",
                                            tint = DarkError
                                        )
                                    }
                                } else {
                                    Icon(
                                        Icons.Default.AccountBalanceWallet,
                                        contentDescription = "Due Payments"
                                    )
                                }
                            }

                            // Settings Icon
                            IconButton(onClick = { viewModel.currentDestination.value = AppDestination.SETTINGS }) {
                                Icon(Icons.Default.Settings, contentDescription = "Settings")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = DarkBackground,
                            titleContentColor = DarkTextPrimary,
                            actionIconContentColor = DarkTextMuted
                        )
                    )
                },
                bottomBar = {
                    if (!isWideScreen) {
                        val navColors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DarkPrimary,
                            selectedTextColor = DarkPrimary,
                            indicatorColor = DarkPrimary.copy(alpha = 0.2f),
                            unselectedIconColor = DarkTextMuted,
                            unselectedTextColor = DarkTextMuted
                        )
                        NavigationBar(
                            containerColor = DarkSurface,
                            modifier = Modifier.border(BorderStroke(1.dp, DarkBorder))
                        ) {
                            NavigationBarItem(
                                selected = currentDestination == AppDestination.DASHBOARD,
                                onClick = { viewModel.currentDestination.value = AppDestination.DASHBOARD },
                                icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
                                label = { Text("Dashboard") },
                                colors = navColors,
                                modifier = Modifier.testTag("nav_dashboard")
                            )
                            NavigationBarItem(
                                selected = currentDestination == AppDestination.SALES,
                                onClick = { viewModel.currentDestination.value = AppDestination.SALES },
                                icon = { Icon(Icons.Default.ShoppingCart, contentDescription = null) },
                                label = { Text("Sales") },
                                colors = navColors,
                                modifier = Modifier.testTag("nav_sales")
                            )
                            NavigationBarItem(
                                selected = currentDestination == AppDestination.INVENTORY,
                                onClick = { viewModel.currentDestination.value = AppDestination.INVENTORY },
                                icon = {
                                    if (lowStockCount > 0) {
                                        BadgedBox(badge = { Badge { Text("$lowStockCount") } }) {
                                            Icon(Icons.Default.Inventory, contentDescription = null)
                                        }
                                    } else {
                                        Icon(Icons.Default.Inventory, contentDescription = null)
                                    }
                                },
                                label = { Text("Stock") },
                                colors = navColors,
                                modifier = Modifier.testTag("nav_inventory")
                            )
                            NavigationBarItem(
                                selected = currentDestination == AppDestination.EXPENSES,
                                onClick = { viewModel.currentDestination.value = AppDestination.EXPENSES },
                                icon = { Icon(Icons.Default.Receipt, contentDescription = null) },
                                label = { Text("Expense") },
                                colors = navColors,
                                modifier = Modifier.testTag("nav_expenses")
                            )
                            NavigationBarItem(
                                selected = currentDestination in listOf(
                                    AppDestination.PRODUCTS,
                                    AppDestination.DUE_PAYMENTS,
                                    AppDestination.REPORTS,
                                    AppDestination.SETTINGS
                                ),
                                onClick = { showMoreSheet = true },
                                icon = { Icon(Icons.Default.MoreHoriz, contentDescription = null) },
                                label = { Text("More") },
                                colors = navColors,
                                modifier = Modifier.testTag("nav_more")
                            )
                        }
                    }
                },
                floatingActionButton = {
                    if (!isWideScreen && currentDestination in listOf(AppDestination.DASHBOARD, AppDestination.SALES)) {
                        FloatingActionButton(
                            onClick = { showAddSaleDialog = true },
                            shape = RoundedCornerShape(18.dp),
                            containerColor = DarkPrimary,
                            contentColor = DarkOnPrimary,
                            modifier = Modifier
                                .border(3.dp, DarkBackground, RoundedCornerShape(18.dp))
                                .testTag("fab_add_sale")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add Sale")
                        }
                    }
                },
                snackbarHost = { SnackbarHost(snackbarHostState) }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (currentDestination) {
                        AppDestination.DASHBOARD -> DashboardScreen(
                            dashboardData = dashboardData,
                            recentSales = sales,
                            lowStockCount = lowStockCount,
                            currencySymbol = settings.currencySymbol,
                            onNavigate = { viewModel.currentDestination.value = it },
                            onAddSaleClick = { showAddSaleDialog = true },
                            onAddExpenseClick = { showAddExpenseDialog = true },
                            onAddProductClick = { showAddProductDialog = true }
                        )

                        AppDestination.SALES -> SalesScreen(
                            sales = sales,
                            currencySymbol = settings.currencySymbol,
                            onAddSaleClick = { showAddSaleDialog = true },
                            onEditSaleClick = { saleToEdit = it },
                            onDeleteSaleClick = { viewModel.deleteSale(it) }
                        )

                        AppDestination.PRODUCTS -> ProductsScreen(
                            products = products,
                            currencySymbol = settings.currencySymbol,
                            onAddProductClick = { showAddProductDialog = true },
                            onEditProductClick = { productToEdit = it },
                            onDeleteProductClick = { viewModel.deleteProduct(it) },
                            onRestockClick = { productToRestock = it }
                        )

                        AppDestination.INVENTORY -> InventoryScreen(
                            inventoryItems = inventoryItems,
                            currencySymbol = settings.currencySymbol,
                            onRestockClick = { productToRestock = it },
                            onAddProductClick = { showAddProductDialog = true }
                        )

                        AppDestination.EXPENSES -> ExpensesScreen(
                            expenses = expenses,
                            currencySymbol = settings.currencySymbol,
                            onAddExpenseClick = { showAddExpenseDialog = true },
                            onEditExpenseClick = { expenseToEdit = it },
                            onDeleteExpenseClick = { viewModel.deleteExpense(it) }
                        )

                        AppDestination.DUE_PAYMENTS -> DuePaymentsScreen(
                            salesWithDue = sales.filter { it.remainingDue > 0 },
                            currencySymbol = settings.currencySymbol,
                            onRecordPayment = { saleId, amount ->
                                viewModel.addDuePayment(saleId, amount)
                            }
                        )

                        AppDestination.REPORTS -> ReportsScreen(
                            sales = sales,
                            expenses = expenses,
                            currencySymbol = settings.currencySymbol,
                            onComputeReport = { period ->
                                viewModel.computeReport(period, sales, expenses)
                            },
                            onComputePerformance = { sortOption ->
                                viewModel.computePerformance(sales, sortOption)
                            }
                        )

                        AppDestination.SETTINGS -> SettingsScreen(
                            settings = settings,
                            onSaveSettings = { viewModel.saveSettings(it) },
                            onExportJson = { viewModel.exportJson() },
                            onImportJson = { viewModel.importJson(it) },
                            onExportCsv = { viewModel.exportCsv(it) },
                            onLoadSampleData = { viewModel.loadSampleData() },
                            onResetAllData = { viewModel.resetAllData() }
                        )
                    }
                }
            }
        }
    }

    // "More" Sheet on Compact Screens
    if (showMoreSheet) {
        ModalBottomSheet(
            onDismissRequest = { showMoreSheet = false },
            sheetState = sheetState,
            containerColor = DarkSurface,
            contentColor = DarkTextPrimary
        ) {
            androidx.compose.foundation.layout.Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "All Business Sections",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = DarkTextPrimary
                )
                Spacer(modifier = Modifier.padding(vertical = 8.dp))

                listOf(
                    Triple(AppDestination.PRODUCTS, "Product Catalog", Icons.Default.Inventory2),
                    Triple(AppDestination.DUE_PAYMENTS, "Due Payments Collection", Icons.Default.AccountBalanceWallet),
                    Triple(AppDestination.REPORTS, "Analytics & Reports", Icons.Default.TrendingUp),
                    Triple(AppDestination.SETTINGS, "Settings & Backups", Icons.Default.Settings)
                ).forEach { (dest, label, icon) ->
                    androidx.compose.material3.Surface(
                        onClick = {
                            viewModel.currentDestination.value = dest
                            scope.launch { sheetState.hide() }.invokeOnCompletion {
                                if (!sheetState.isVisible) showMoreSheet = false
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        color = if (currentDestination == dest) DarkPrimary.copy(alpha = 0.15f) else Color.Transparent,
                        border = if (currentDestination == dest) BorderStroke(1.dp, DarkPrimary.copy(alpha = 0.4f)) else null,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(icon, contentDescription = null, tint = if (currentDestination == dest) DarkPrimary else DarkTextMuted)
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = label,
                                fontWeight = FontWeight.SemiBold,
                                color = if (currentDestination == dest) DarkPrimary else DarkTextPrimary
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.padding(vertical = 12.dp))
            }
        }
    }

    // Add / Edit Sale Dialog
    if (showAddSaleDialog || saleToEdit != null) {
        AddEditSaleDialog(
            existingSale = saleToEdit,
            products = products,
            allowNegativeStock = settings.allowNegativeStock,
            onDismiss = {
                showAddSaleDialog = false
                saleToEdit = null
            },
            onSave = { sale ->
                if (saleToEdit != null) {
                    viewModel.updateSale(saleToEdit!!, sale)
                } else {
                    viewModel.recordSale(sale)
                }
                showAddSaleDialog = false
                saleToEdit = null
            }
        )
    }

    // Add / Edit Product Dialog
    if (showAddProductDialog || productToEdit != null) {
        AddEditProductDialog(
            existingProduct = productToEdit,
            onDismiss = {
                showAddProductDialog = false
                productToEdit = null
            },
            onSave = { product ->
                viewModel.saveProduct(product)
                showAddProductDialog = false
                productToEdit = null
            }
        )
    }

    // Add / Edit Expense Dialog
    if (showAddExpenseDialog || expenseToEdit != null) {
        AddEditExpenseDialog(
            existingExpense = expenseToEdit,
            onDismiss = {
                showAddExpenseDialog = false
                expenseToEdit = null
            },
            onSave = { expense ->
                viewModel.saveExpense(expense)
                showAddExpenseDialog = false
                expenseToEdit = null
            }
        )
    }

    // Quick Restock Dialog
    productToRestock?.let { prod ->
        QuickRestockDialog(
            product = prod,
            onDismiss = { productToRestock = null },
            onConfirm = { newStock ->
                viewModel.quickRestock(prod.id, newStock)
                productToRestock = null
            }
        )
    }
}
