package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_settings")
data class AppSettings(
    @PrimaryKey
    val id: Int = 1,
    val businessName: String = "My Clothing Boutique",
    val allowNegativeStock: Boolean = false,
    val currencySymbol: String = "৳",
    val darkMode: Boolean = true,
    val useSystemTheme: Boolean = false
)
