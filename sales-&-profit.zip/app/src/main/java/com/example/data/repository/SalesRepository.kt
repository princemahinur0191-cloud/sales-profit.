package com.example.data.repository

import com.example.data.dao.AppSettingsDao
import com.example.data.dao.ExpenseDao
import com.example.data.dao.ProductDao
import com.example.data.dao.SaleDao
import com.example.data.model.AppSettings
import com.example.data.model.Expense
import com.example.data.model.Product
import com.example.data.model.Sale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SalesRepository(
    private val productDao: ProductDao,
    private val saleDao: SaleDao,
    private val expenseDao: ExpenseDao,
    private val appSettingsDao: AppSettingsDao
) {
    val allProducts: Flow<List<Product>> = productDao.getAllProducts()
    val allSales: Flow<List<Sale>> = saleDao.getAllSales()
    val allExpenses: Flow<List<Expense>> = expenseDao.getAllExpenses()
    val settings: Flow<AppSettings> = appSettingsDao.getSettings().map {
        it ?: AppSettings()
    }

    suspend fun getSettingsDirect(): AppSettings = withContext(Dispatchers.IO) {
        appSettingsDao.getSettingsDirect() ?: AppSettings()
    }

    suspend fun saveSettings(settings: AppSettings) = withContext(Dispatchers.IO) {
        appSettingsDao.insertOrUpdateSettings(settings)
    }

    suspend fun insertProduct(product: Product): Long = withContext(Dispatchers.IO) {
        productDao.insertProduct(product)
    }

    suspend fun updateProduct(product: Product) = withContext(Dispatchers.IO) {
        productDao.updateProduct(product)
    }

    suspend fun deleteProduct(product: Product) = withContext(Dispatchers.IO) {
        productDao.deleteProduct(product)
    }

    suspend fun updateProductStock(productId: Long, newStock: Int) = withContext(Dispatchers.IO) {
        productDao.updateStock(productId, newStock)
    }

    suspend fun recordSale(sale: Sale, allowNegativeStock: Boolean): Result<Long> = withContext(Dispatchers.IO) {
        try {
            val product = productDao.getProductById(sale.productId)
            if (product != null) {
                if (!allowNegativeStock && product.currentStock < sale.quantity) {
                    return@withContext Result.failure(
                        Exception("Insufficient stock! Available: ${product.currentStock} pieces, but trying to sell: ${sale.quantity}")
                    )
                }
                val newStock = product.currentStock - sale.quantity
                productDao.updateStock(product.id, newStock)
            }
            val saleId = saleDao.insertSale(sale)
            Result.success(saleId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateSale(
        oldSale: Sale,
        newSale: Sale,
        allowNegativeStock: Boolean
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (oldSale.productId == newSale.productId) {
                val product = productDao.getProductById(newSale.productId)
                if (product != null) {
                    val stockDelta = oldSale.quantity - newSale.quantity
                    val adjustedStock = product.currentStock + stockDelta
                    if (!allowNegativeStock && adjustedStock < 0) {
                        return@withContext Result.failure(
                            Exception("Insufficient stock for update! Available: ${product.currentStock}, Needed: ${newSale.quantity - oldSale.quantity}")
                        )
                    }
                    productDao.updateStock(product.id, adjustedStock)
                }
            } else {
                // Product changed
                val oldProduct = productDao.getProductById(oldSale.productId)
                if (oldProduct != null) {
                    productDao.updateStock(oldProduct.id, oldProduct.currentStock + oldSale.quantity)
                }
                val newProduct = productDao.getProductById(newSale.productId)
                if (newProduct != null) {
                    if (!allowNegativeStock && newProduct.currentStock < newSale.quantity) {
                        return@withContext Result.failure(
                            Exception("Insufficient stock for new product! Available: ${newProduct.currentStock}")
                        )
                    }
                    productDao.updateStock(newProduct.id, newProduct.currentStock - newSale.quantity)
                }
            }
            saleDao.updateSale(newSale)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteSale(sale: Sale): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val product = productDao.getProductById(sale.productId)
            if (product != null) {
                productDao.updateStock(product.id, product.currentStock + sale.quantity)
            }
            saleDao.deleteSale(sale)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateDuePayment(saleId: Long, additionalPayment: Double): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val sale = saleDao.getSaleById(saleId) ?: return@withContext Result.failure(Exception("Sale not found"))
            val updatedPaid = (sale.amountPaid + additionalPayment).coerceAtMost(sale.totalRevenue)
            val updatedDue = (sale.totalRevenue - updatedPaid).coerceAtLeast(0.0)
            val updatedStatus = if (updatedDue <= 0.0) "Paid" else "Partial"
            val updatedSale = sale.copy(
                amountPaid = updatedPaid,
                remainingDue = updatedDue,
                paymentStatus = updatedStatus
            )
            saleDao.updateSale(updatedSale)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun insertExpense(expense: Expense): Long = withContext(Dispatchers.IO) {
        expenseDao.insertExpense(expense)
    }

    suspend fun updateExpense(expense: Expense) = withContext(Dispatchers.IO) {
        expenseDao.updateExpense(expense)
    }

    suspend fun deleteExpense(expense: Expense) = withContext(Dispatchers.IO) {
        expenseDao.deleteExpense(expense)
    }

    suspend fun resetAllData() = withContext(Dispatchers.IO) {
        saleDao.clearAllSales()
        expenseDao.clearAllExpenses()
        productDao.clearAllProducts()
        appSettingsDao.insertOrUpdateSettings(AppSettings())
    }

    suspend fun loadSampleData() = withContext(Dispatchers.IO) {
        val sampleProducts = listOf(
            Product(
                name = "Drop Shoulder T-Shirt",
                category = "T-Shirts",
                buyingPrice = 280.0,
                sellingPrice = 450.0,
                currentStock = 35,
                minStockAlert = 5,
                notes = "100% combed cotton, 220 GSM"
            ),
            Product(
                name = "Polo T-Shirt",
                category = "Polo",
                buyingPrice = 350.0,
                sellingPrice = 580.0,
                currentStock = 24,
                minStockAlert = 5,
                notes = "Pique knit collar, premium finish"
            ),
            Product(
                name = "Export Casual Shirt",
                category = "Shirts",
                buyingPrice = 480.0,
                sellingPrice = 850.0,
                currentStock = 18,
                minStockAlert = 4,
                notes = "Oxford cotton slim fit"
            ),
            Product(
                name = "Slim Fit Denim Pant",
                category = "Pants",
                buyingPrice = 650.0,
                sellingPrice = 1150.0,
                currentStock = 12,
                minStockAlert = 3,
                notes = "Stretchable indigo denim"
            ),
            Product(
                name = "Festive Cotton Panjabi",
                category = "Traditional",
                buyingPrice = 750.0,
                sellingPrice = 1350.0,
                currentStock = 8,
                minStockAlert = 3,
                notes = "Hand embroidered collar"
            )
        )
        productDao.insertProducts(sampleProducts)

        // Load inserted products to get generated IDs
        val now = System.currentTimeMillis()
        val oneHour = 3600000L
        val oneDay = 86400000L

        val sampleSales = listOf(
            Sale(
                date = now - (2 * oneHour),
                productId = 1,
                productName = "Drop Shoulder T-Shirt",
                quantity = 3,
                buyingPricePerPiece = 280.0,
                sellingPricePerPiece = 450.0,
                totalRevenue = 1350.0,
                totalCost = 840.0,
                grossProfit = 510.0,
                customerName = "Tanvir Ahmed",
                customerPhone = "01711223344",
                paymentStatus = "Paid",
                paymentMethod = "bKash",
                amountPaid = 1350.0,
                remainingDue = 0.0,
                notes = "Red & Black variants"
            ),
            Sale(
                date = now - (5 * oneHour),
                productId = 2,
                productName = "Polo T-Shirt",
                quantity = 2,
                buyingPricePerPiece = 350.0,
                sellingPricePerPiece = 580.0,
                totalRevenue = 1160.0,
                totalCost = 700.0,
                grossProfit = 460.0,
                customerName = "Rafiqul Islam",
                customerPhone = "01819887766",
                paymentStatus = "Paid",
                paymentMethod = "Cash",
                amountPaid = 1160.0,
                remainingDue = 0.0,
                notes = "In-store walk-in"
            ),
            Sale(
                date = now - oneDay,
                productId = 3,
                productName = "Export Casual Shirt",
                quantity = 2,
                buyingPricePerPiece = 480.0,
                sellingPricePerPiece = 850.0,
                totalRevenue = 1700.0,
                totalCost = 960.0,
                grossProfit = 740.0,
                customerName = "Mahmud Hasan",
                customerPhone = "01912345678",
                paymentStatus = "Partial",
                paymentMethod = "Nagad",
                amountPaid = 1000.0,
                remainingDue = 700.0,
                notes = "Paid ৳1000 via Nagad, due ৳700"
            ),
            Sale(
                date = now - (2 * oneDay),
                productId = 4,
                productName = "Slim Fit Denim Pant",
                quantity = 1,
                buyingPricePerPiece = 650.0,
                sellingPricePerPiece = 1150.0,
                totalRevenue = 1150.0,
                totalCost = 650.0,
                grossProfit = 500.0,
                customerName = "Saiful Karim",
                customerPhone = "01678990011",
                paymentStatus = "Due",
                paymentMethod = "Other",
                amountPaid = 0.0,
                remainingDue = 1150.0,
                notes = "Friend reference, promise to pay on Friday"
            )
        )
        saleDao.insertSales(sampleSales)

        val sampleExpenses = listOf(
            Expense(
                date = now - (3 * oneHour),
                category = "Packaging",
                amount = 450.0,
                description = "100 Poly mailer delivery bags with logo"
            ),
            Expense(
                date = now - oneDay,
                category = "Facebook promotion",
                amount = 1200.0,
                description = "Boosted post for new Eid collection"
            ),
            Expense(
                date = now - (2 * oneDay),
                category = "Delivery",
                amount = 350.0,
                description = "Pathao Courier merchant delivery charges"
            ),
            Expense(
                date = now - (5 * oneDay),
                category = "Transport",
                amount = 250.0,
                description = "CNG rickshaw fare to Islampur market"
            )
        )
        expenseDao.insertExpenses(sampleExpenses)
    }

    suspend fun exportAllDataAsJson(
        products: List<Product>,
        sales: List<Sale>,
        expenses: List<Expense>,
        settings: AppSettings
    ): String = withContext(Dispatchers.Default) {
        val root = JSONObject()
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())

        val settingsObj = JSONObject().apply {
            put("businessName", settings.businessName)
            put("allowNegativeStock", settings.allowNegativeStock)
            put("currencySymbol", settings.currencySymbol)
            put("darkMode", settings.darkMode)
            put("useSystemTheme", settings.useSystemTheme)
        }
        root.put("settings", settingsObj)

        val prodArray = JSONArray()
        for (p in products) {
            prodArray.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("category", p.category)
                put("buyingPrice", p.buyingPrice)
                put("sellingPrice", p.sellingPrice)
                put("currentStock", p.currentStock)
                put("minStockAlert", p.minStockAlert)
                put("notes", p.notes)
                put("createdAt", p.createdAt)
            })
        }
        root.put("products", prodArray)

        val saleArray = JSONArray()
        for (s in sales) {
            saleArray.put(JSONObject().apply {
                put("id", s.id)
                put("date", s.date)
                put("productId", s.productId)
                put("productName", s.productName)
                put("quantity", s.quantity)
                put("buyingPricePerPiece", s.buyingPricePerPiece)
                put("sellingPricePerPiece", s.sellingPricePerPiece)
                put("totalRevenue", s.totalRevenue)
                put("totalCost", s.totalCost)
                put("grossProfit", s.grossProfit)
                put("customerName", s.customerName)
                put("customerPhone", s.customerPhone)
                put("paymentStatus", s.paymentStatus)
                put("paymentMethod", s.paymentMethod)
                put("amountPaid", s.amountPaid)
                put("remainingDue", s.remainingDue)
                put("notes", s.notes)
            })
        }
        root.put("sales", saleArray)

        val expArray = JSONArray()
        for (e in expenses) {
            expArray.put(JSONObject().apply {
                put("id", e.id)
                put("date", e.date)
                put("category", e.category)
                put("amount", e.amount)
                put("description", e.description)
            })
        }
        root.put("expenses", expArray)

        root.toString(2)
    }

    suspend fun importDataFromJson(jsonStr: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonStr)

            // Import Settings
            if (root.has("settings")) {
                val sObj = root.getJSONObject("settings")
                val s = AppSettings(
                    id = 1,
                    businessName = sObj.optString("businessName", "My Clothing Boutique"),
                    allowNegativeStock = sObj.optBoolean("allowNegativeStock", false),
                    currencySymbol = sObj.optString("currencySymbol", "৳"),
                    darkMode = sObj.optBoolean("darkMode", false),
                    useSystemTheme = sObj.optBoolean("useSystemTheme", true)
                )
                appSettingsDao.insertOrUpdateSettings(s)
            }

            // Import Products
            if (root.has("products")) {
                val prodArray = root.getJSONArray("products")
                val prods = mutableListOf<Product>()
                for (i in 0 until prodArray.length()) {
                    val p = prodArray.getJSONObject(i)
                    prods.add(
                        Product(
                            id = p.optLong("id", 0L),
                            name = p.getString("name"),
                            category = p.optString("category", "General"),
                            buyingPrice = p.optDouble("buyingPrice", 0.0),
                            sellingPrice = p.optDouble("sellingPrice", 0.0),
                            currentStock = p.optInt("currentStock", 0),
                            minStockAlert = p.optInt("minStockAlert", 5),
                            notes = p.optString("notes", ""),
                            createdAt = p.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
                productDao.clearAllProducts()
                productDao.insertProducts(prods)
            }

            // Import Sales
            if (root.has("sales")) {
                val saleArray = root.getJSONArray("sales")
                val sales = mutableListOf<Sale>()
                for (i in 0 until saleArray.length()) {
                    val s = saleArray.getJSONObject(i)
                    sales.add(
                        Sale(
                            id = s.optLong("id", 0L),
                            date = s.optLong("date", System.currentTimeMillis()),
                            productId = s.optLong("productId", 0L),
                            productName = s.getString("productName"),
                            quantity = s.getInt("quantity"),
                            buyingPricePerPiece = s.optDouble("buyingPricePerPiece", 0.0),
                            sellingPricePerPiece = s.optDouble("sellingPricePerPiece", 0.0),
                            totalRevenue = s.optDouble("totalRevenue", 0.0),
                            totalCost = s.optDouble("totalCost", 0.0),
                            grossProfit = s.optDouble("grossProfit", 0.0),
                            customerName = s.optString("customerName", ""),
                            customerPhone = s.optString("customerPhone", ""),
                            paymentStatus = s.optString("paymentStatus", "Paid"),
                            paymentMethod = s.optString("paymentMethod", "Cash"),
                            amountPaid = s.optDouble("amountPaid", 0.0),
                            remainingDue = s.optDouble("remainingDue", 0.0),
                            notes = s.optString("notes", "")
                        )
                    )
                }
                saleDao.clearAllSales()
                saleDao.insertSales(sales)
            }

            // Import Expenses
            if (root.has("expenses")) {
                val expArray = root.getJSONArray("expenses")
                val expenses = mutableListOf<Expense>()
                for (i in 0 until expArray.length()) {
                    val e = expArray.getJSONObject(i)
                    expenses.add(
                        Expense(
                            id = e.optLong("id", 0L),
                            date = e.optLong("date", System.currentTimeMillis()),
                            category = e.getString("category"),
                            amount = e.getDouble("amount"),
                            description = e.optString("description", "")
                        )
                    )
                }
                expenseDao.clearAllExpenses()
                expenseDao.insertExpenses(expenses)
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun generateCsv(type: String, products: List<Product>, sales: List<Sale>, expenses: List<Expense>): String = withContext(Dispatchers.Default) {
        val dateFormat = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault())
        val sb = StringBuilder()
        when (type.lowercase()) {
            "sales" -> {
                sb.append("ID,Date,Product,Quantity,Cost/Piece,Selling/Piece,Revenue,Total Cost,Gross Profit,Customer,Phone,Status,Method,Amount Paid,Due,Notes\n")
                for (s in sales) {
                    val d = dateFormat.format(Date(s.date))
                    val cName = s.customerName.replace(",", " ")
                    val pName = s.productName.replace(",", " ")
                    val note = s.notes.replace(",", " ")
                    sb.append("${s.id},\"$d\",\"$pName\",${s.quantity},${s.buyingPricePerPiece},${s.sellingPricePerPiece},${s.totalRevenue},${s.totalCost},${s.grossProfit},\"$cName\",${s.customerPhone},${s.paymentStatus},${s.paymentMethod},${s.amountPaid},${s.remainingDue},\"$note\"\n")
                }
            }
            "expenses" -> {
                sb.append("ID,Date,Category,Amount,Description\n")
                for (e in expenses) {
                    val d = dateFormat.format(Date(e.date))
                    val desc = e.description.replace(",", " ")
                    sb.append("${e.id},\"$d\",${e.category},${e.amount},\"$desc\"\n")
                }
            }
            "products" -> {
                sb.append("ID,Product Name,Category,Buying Price,Selling Price,Stock,Min Alert,Stock Value,Potential Revenue,Potential Profit\n")
                for (p in products) {
                    val pName = p.name.replace(",", " ")
                    val stockVal = p.currentStock * p.buyingPrice
                    val potRev = p.currentStock * p.sellingPrice
                    val potProfit = potRev - stockVal
                    sb.append("${p.id},\"$pName\",${p.category},${p.buyingPrice},${p.sellingPrice},${p.currentStock},${p.minStockAlert},$stockVal,$potRev,$potProfit\n")
                }
            }
        }
        sb.toString()
    }
}
