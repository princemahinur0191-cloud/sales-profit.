package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: Long = System.currentTimeMillis(),
    val productId: Long,
    val productName: String,
    val quantity: Int,
    val buyingPricePerPiece: Double,
    val sellingPricePerPiece: Double,
    val totalRevenue: Double,
    val totalCost: Double,
    val grossProfit: Double,
    val customerName: String = "",
    val customerPhone: String = "",
    val paymentStatus: String = "Paid", // "Paid", "Partial", "Due"
    val paymentMethod: String = "Cash", // "Cash", "bKash", "Nagad", "Bank", "Other"
    val amountPaid: Double = 0.0,
    val remainingDue: Double = 0.0,
    val notes: String = ""
)
