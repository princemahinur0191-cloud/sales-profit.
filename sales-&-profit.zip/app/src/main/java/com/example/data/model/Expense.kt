package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: Long = System.currentTimeMillis(),
    val category: String, // "Delivery", "Transport", "Packaging", "Electricity", "Advertising", "Facebook promotion", "Phone/Internet", "Rent", "Other"
    val amount: Double,
    val description: String = ""
)
