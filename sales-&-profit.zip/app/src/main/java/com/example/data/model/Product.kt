package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String,
    val buyingPrice: Double,
    val sellingPrice: Double,
    val currentStock: Int,
    val minStockAlert: Int = 5,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
